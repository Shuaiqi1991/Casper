library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BTG_STDAMT_STATED_AMT_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BTG_STDAMT', 'STATED_AMT_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[, BTG_STDAMT_STATED_AMT_GRP:=paste0(BTG_STDAMT, '_', STATED_AMT_GRP)]
  
  # FORMATTING
  base_data[, BTG_STDAMT_STATED_AMT_GRP:=as.factor(BTG_STDAMT_STATED_AMT_GRP)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
