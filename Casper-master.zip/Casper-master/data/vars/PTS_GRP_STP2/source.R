library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'PTS_GRP_STP2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('AGE_AND_PTS')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # DUPLICATE VARIABLE
  base_data[, PTS_GRP_NAME_STP2:=paste0(PTS_GRP_NAME, '_STP2')]
  base_data[PTS_GRP_NAME %in% c('PTS_GRP_05', 'PTS_GRP_06', 'PTS_GRP_07', 'PTS_GRP_08',
                                'PTS_GRP_09', 'PTS_GRP_10', 'PTS_GRP_11'),
            PTS_GRP_NAME_STP2:='PTS_GRP_GE5_STP2']
  base_data[, PTS_GRP_NAME_STP2:=as.factor(PTS_GRP_NAME_STP2)]
  base_data[, PTS_GRP_XX_STP2:=PTS_GRP_XX]
  base_data[, PTS_GRP_00_STP2:=PTS_GRP_00]
  base_data[, PTS_GRP_01_STP2:=PTS_GRP_01]
  base_data[, PTS_GRP_02_STP2:=PTS_GRP_02]
  base_data[, PTS_GRP_03_STP2:=PTS_GRP_03]
  base_data[, PTS_GRP_04_STP2:=PTS_GRP_04]
  base_data[, PTS_GRP_GE5_STP2:=PTS_GRP_05+PTS_GRP_06+PTS_GRP_07+PTS_GRP_08+
              PTS_GRP_09+PTS_GRP_10+PTS_GRP_11]
			  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
