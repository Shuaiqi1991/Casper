library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BTG_BC'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLES
  lookup_bt <- fread(here(var_lib_path, 'BTG_BC', 'lookup_bt.csv'))
  
  # FORMATTING
  lookup_bt[, VEH_BODY_TYP:=str_pad(VEH_BODY_TYP, width=2, side='left', pad='0')]
  
  # DELETE EXISTING VARIABLE, IF IT EXISTS
  if ('BTG_BC' %in% names(base_data)) base_data[, BTG_BC:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- lookup_bt[base_data, on=.(VEH_BODY_TYP)]
  
  # NAs
  base_data[is.na(BTG_BC), BTG_BC:='Light']
  
  # ENSURE FACTOR FORMATTING
  base_data[, BTG_BC:=as.factor(BTG_BC)]
  base_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
