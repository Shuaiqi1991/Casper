library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BC_BT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BCG_BT', 'BTG_BC')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE
  base_data[, BC_BT:=paste0(BCG_BT, '_', BTG_BC)]
  
  # ENSURE FACTOR FORMATTING
  base_data[, BC_BT:=as.factor(BC_BT)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
