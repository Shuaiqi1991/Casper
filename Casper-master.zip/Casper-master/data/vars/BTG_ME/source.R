library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BTG_ME'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ IN LOOKUP TABLE
  lookup_bt <- fread(here(var_lib_path, 'BTG_ME', 'lookup_bt.csv'))

  # FORMATTING
  for (j in names(lookup_bt)) set(lookup_bt, j=j, value=as.character(lookup_bt[[j]]))
    
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('BTG_ME' %in% names(base_data)) base_data[, BTG_ME:=NULL]

  # JOIN BTG_ME ONTO BASE DATASET
  base_data <- lookup_bt[, .(VEH_BODY_TYP, BTG_ME)][base_data, on=.(VEH_BODY_TYP)]
  base_data[is.na(BTG_ME), BTG_ME:='UNK']
  base_data[, BTG_ME:=as.factor(BTG_ME)]
  base_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}