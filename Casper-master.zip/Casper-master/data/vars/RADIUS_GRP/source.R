library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'RADIUS_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN POLICIES
  caw_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_OPR_RAD
    FROM 
      CAW.VEHICLE, 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.VEHICLE.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_OPR_RAD
    ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERIES
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # FORMATTING
  caw_data[, VEH_OPR_RAD:=as.character(VEH_OPR_RAD)]
  caw_data[, VEH_OPR_RAD:=trimws(VEH_OPR_RAD)]
  
  # GROUPINGS
  caw_data[, RADIUS_GRP:=VEH_OPR_RAD]
  caw_data[VEH_OPR_RAD %in% c('050', '051', '51', '50'), RADIUS_GRP:='50']
  caw_data[VEH_OPR_RAD %in% c('100','101'), RADIUS_GRP:='100']
  caw_data[VEH_OPR_RAD %in% c('200','201'), RADIUS_GRP:='200']
  caw_data[VEH_OPR_RAD %in% c('300','301'), RADIUS_GRP:='300']
  caw_data[VEH_OPR_RAD %in% c('500','501'), RADIUS_GRP:='500']
  caw_data[, VEH_OPR_RAD:=NULL]

  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('RADIUS_GRP' %in% names(base_data)) base_data[, RADIUS_GRP:=NULL]

  # JOIN ONTO BASE DATASET
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # FORMATTING
  base_data[! RADIUS_GRP %in% c('50','100','200','300','500','999'), RADIUS_GRP:='999']
  base_data[, RADIUS_GRP:=as.factor(RADIUS_GRP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}
