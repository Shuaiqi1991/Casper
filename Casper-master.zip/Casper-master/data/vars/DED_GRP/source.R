library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'DED_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('DED_AMT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_ded <- fread(here(var_lib_path, 'DED_GRP', 'lookup_ded.csv'))
  lookup_ded[, DED_AMT:=as.factor(DED_AMT)]
  lookup_ded[, DED_GRP:=as.factor(DED_GRP)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('DED_GRP' %in% names(base_data)) base_data[, DED_GRP:=NULL]
  
  # JOIN DED ONTO BASE DATASET
  base_data <- lookup_ded[base_data, on=.(DED_AMT)]
  
  # FORMATTING
  base_data[is.na(DED_GRP), DED_GRP:='999']
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
