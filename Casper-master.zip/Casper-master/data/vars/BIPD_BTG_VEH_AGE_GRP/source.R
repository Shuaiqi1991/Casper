library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BIPD_BTG_VEH_AGE_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP', 'BMT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_btg <- fread(here(var_lib_path, 'BIPD_BTG_VEH_AGE_GRP', 'lookup_btg.csv'))
  lookup_btg[, VEH_BODY_TYP:=str_pad(VEH_BODY_TYP, side='left', width=2, pad='0')]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('BIPD_BTG_VEH_AGE_GRP' %in% names(base_data)) base_data[, BIPD_BTG_VEH_AGE_GRP:=NULL]
  
  # LOOKUP BTG GRP
  base_data <- lookup_btg[base_data, on=.(VEH_BODY_TYP)]
  base_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]

  # REMOVE MISSING OR NA VALUES
  base_data[is.na(BIPD_BTG_VEH_AGE_GRP), BIPD_BTG_VEH_AGE_GRP:='Pickups']
  
  # FACTORIZE
  base_data[, BIPD_BTG_VEH_AGE_GRP:=as.factor(BIPD_BTG_VEH_AGE_GRP)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
