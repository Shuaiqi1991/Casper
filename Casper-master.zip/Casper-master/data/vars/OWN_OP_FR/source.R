library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'OWN_OP_FR'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('FR_NO_LIST', 'DRVR_CNT', 'POWER_UNIT_CNT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD OWNER OPERATOR VARIABLE
  base_data[POWER_UNIT_CNT==1 & DRVR_CNT==1 & FR_NO_LIST=='N', OWN_OP_FR:='1 by 1 FR']
  base_data[POWER_UNIT_CNT==1 & DRVR_CNT==1 & FR_NO_LIST=='Y', OWN_OP_FR:='1 by 1 no FR']
  base_data[!(POWER_UNIT_CNT==1 & DRVR_CNT==1) & FR_NO_LIST=='N', OWN_OP_FR:='N by M FR']
  base_data[!(POWER_UNIT_CNT==1 & DRVR_CNT==1) & FR_NO_LIST=='Y', OWN_OP_FR:='N by M no FR']
  base_data[, OWN_OP_FR:=as.factor(OWN_OP_FR)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
