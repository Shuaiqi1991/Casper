library(data.table)
library(odbc)
library(lubridate)

# DEFINE VARIABLE
var_name <- 'PRIOR_TERM_EDS_CNT_OLD'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # REPLACE DATES IN QUERY
  start_date_minus_3yr <- as.Date(start_date) %m+% lubridate::years(-3)
  start_date_minus_3yr <- as.character(start_date_minus_3yr)
  end_date_plus_1yr <- as.Date(end_date) %m+% lubridate::years(1)
  end_date_plus_1yr <- as.character(end_date_plus_1yr)
  date_seq <- seq(as.Date(start_date_minus_3yr), as.Date(end_date_plus_1yr) %m+% days(1), by='year')
  date_seq <- c(date_seq, as.Date(end_date_plus_1yr) %m+% days(1))
  date_seq <- unique(date_seq)
  
  # QUERY IS TOO LARGE TO RUN ALL AT ONCE
  # RUN MULTIPLE TIMES OVER SEVERAL SEGMENTS OF TIME,
  # THEN STACK THE DATASETS
  drv_data <- lapply(1:(length(date_seq)-1), function(x){
    # DRIVER QUERY
    drv_qry <- "
      SELECT 
        CAW.DRVR_DATES.ST_CD, 
        CAW.DRVR_DATES.PHYS_POL_KEY, 
        CAW.DRVR_DATES.POL_STRT_DT, 
        CAW.DRVR_DATES.POL_STOP_DT, 
        CAW.DRVR_DATES.DRVR_STRT_DT, 
        CAW.DRVR_DATES.DRVR_STOP_DT, 
        CAW.DRVR_PUB_VIEW.LST_NAM, 
        CAW.DRVR_PUB_VIEW.DRVR_BRTH_DT, 
        CAW.DRVR_SEC_VIEW.DRVR_LIC_NBR, 
        CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND 
      FROM 
        CAW.DRVR_SEC_VIEW, 
        CAW.DRVR_PUB_VIEW, 
        CAW.DRVR_DATES 
      WHERE 
        CAW.DRVR_DATES.ST_CD = CAW.DRVR_PUB_VIEW.ST_CD 
        AND CAW.DRVR_DATES.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
        AND CAW.DRVR_DATES.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
        AND CAW.DRVR_DATES.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
        AND CAW.DRVR_DATES.DRVR_POS_CNT = CAW.DRVR_PUB_VIEW.DRVR_POS_CNT 
        AND CAW.DRVR_DATES.DRVR_VRSN_NBR = CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR 
        AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_SEC_VIEW.ST_CD 
        AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_SEC_VIEW.POL_ID_CHAR 
        AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_SEC_VIEW.RENW_SFX_NBR 
        AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_SEC_VIEW.POL_EXPR_YR 
        AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_SEC_VIEW.DRVR_POS_CNT 
        AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_SEC_VIEW.DRVR_VRSN_NBR 
        AND CAW.DRVR_DATES.POL_STOP_DT >= {d 'seg_start'}
        AND CAW.DRVR_DATES.POL_STOP_DT < {d 'seg_end'}
        ;
    "
    
    # REPLACE DATES IN QUERY
    seg_start <- as.character(date_seq[x])
    seg_end <- as.character(date_seq[x+1])
    drv_qry <- str_replace_all(drv_qry, 'seg_start', seg_start)
    drv_qry <- str_replace_all(drv_qry, 'seg_end', seg_end)
    
    # RUN QUERY
    drv_seg <- as.data.table(dbGetQuery(caw_con, drv_qry))
    
    # RETURN SEGMENT
    return(drv_seg)
  })

  # STACK THE DATA
  drv_data <- rbindlist(drv_data)
  
  # REMOVE DUPLICATES (GET FIRST ROW FOR EACH GROUP)
  drv_data <- drv_data[, .SD[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_STRT_DT, DRVR_STOP_DT)]
  
  # REMOVE BLANK DRVR LIC AND MOCK IND
  drv_data <- drv_data[DRVR_MOCK_IND!='Y']
  drv_data[, DRVR_LIC_NBR:=trimws(DRVR_LIC_NBR)]
  drv_data <- drv_data[DRVR_LIC_NBR!='']
  
  # CREATE ALTERNATIVE DRIVER IDENTIFIER
  drv_data[, ALT_KEY:=paste0(trimws(LST_NAM), trimws(DRVR_BRTH_DT))]
  
  # REMOVE MULTIPLE VERSIONS THAT HAVE SAME START DATE
  # KEEP MAXIMUM STOP DATE
  drv_data <- drv_data[, .(DRVR_STOP_DT=max(DRVR_STOP_DT)), 
                       by=.(ST_CD, PHYS_POL_KEY, POL_STRT_DT, POL_STOP_DT, 
                            ALT_KEY, DRVR_STRT_DT)]
  # REMOVE MULTIPLE VERSIONS THAT HAVE SAME STOP DATE
  # KEEP MINIMUM START DATE
  drv_data <- drv_data[, .(DRVR_STRT_DT=min(DRVR_STRT_DT)),
                       by=.(ST_CD, PHYS_POL_KEY, POL_STRT_DT, POL_STOP_DT,
                            ALT_KEY, DRVR_STOP_DT)]
  
  # SORT DATA
  drv_data <- drv_data[order(ST_CD, PHYS_POL_KEY, ALT_KEY, DRVR_STRT_DT, DRVR_STOP_DT)]
  
  # GET START DATE OF NEXT VERSION FOR EACH DRIVER VERSION
  drv_data[, NEXT_STRT:=shift(DRVR_STRT_DT, 1, type='lead'), by=.(ST_CD, PHYS_POL_KEY, ALT_KEY)]
  
  # GET MAXIMUM STOP DATE UP TO THAT POINT FOR EACH DRIVER VERSION
  drv_data[, MAX_STOP:=cummax(as.numeric(DRVR_STOP_DT)), by=.(ST_CD, PHYS_POL_KEY, ALT_KEY)]
  
  # CALCULATE AND LABEL VERSIONS WHICH CHAIN TOGETHER OR OVERLAP
  drv_data[, CHAIN_ID:=c(0, cumsum(NEXT_STRT > MAX_STOP)[-.N]), by=.(ST_CD, PHYS_POL_KEY, ALT_KEY)]
  
  # GET RANGE FOR EACH DRIVER VERSION
  drv_data <- drv_data[, .(DRVR_STRT_DT=min(DRVR_STRT_DT),
                           DRVR_STOP_DT=max(DRVR_STOP_DT)),
                       by=.(ST_CD, PHYS_POL_KEY, ALT_KEY, CHAIN_ID, POL_STRT_DT, POL_STOP_DT)]

  # COUNT ADDITIONS AND DELETIONS
  drv_data[, DRVR_ADD:=(DRVR_STRT_DT>POL_STRT_DT)*1]
  drv_data[, DRVR_REM:=(DRVR_STOP_DT<POL_STOP_DT)*1]
  
  # VEHICLE QUERY
  veh_qry <- "
    SELECT 
    	CAW.VEH_DATES.ST_CD, 
      CAW.VEH_DATES.PHYS_POL_KEY, 
      CAW.VEH_DATES.POL_STRT_DT, 
      CAW.VEH_DATES.POL_STOP_DT, 
      CAW.VEH_DATES.VEH_STRT_DT, 
      CAW.VEH_DATES.VEH_STOP_DT, 
      CAW.VEHICLE.VIN, 
      CAW.VEHICLE.VEH_MODL_YR 
    FROM 
      CAW.VEHICLE, 
      CAW.VEH_DATES,
      CAW.BODYTYP
    WHERE 
      CAW.VEH_DATES.POL_STOP_DT BETWEEN {d 'start_date_minus_3yr'} AND {d 'end_date_plus_1yr'}
      AND CAW.VEH_DATES.POL_ID_CHAR = CAW.VEHICLE.POL_ID_CHAR 
      AND CAW.VEH_DATES.RENW_SFX_NBR = CAW.VEHICLE.RENW_SFX_NBR 
      AND CAW.VEH_DATES.POL_EXPR_YR = CAW.VEHICLE.POL_EXPR_YR 
      AND CAW.VEH_DATES.VEH_POS_CNT = CAW.VEHICLE.VEH_POS_CNT 
      AND CAW.VEH_DATES.VEH_VRSN_NBR = CAW.VEHICLE.VEH_VRSN_NBR 
      AND CAW.BODYTYP.TRLR_OR_POWER  = 'P'
      AND CAW.VEHICLE.VEH_BODY_TYP = CAW.BODYTYP.VEH_BODY_TYP 
    ;
  "
  
  # REPLACE DATES IN QUERY
  veh_qry <- str_replace_all(veh_qry, 'start_date_minus_3yr', start_date_minus_3yr)
  veh_qry <- str_replace_all(veh_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # RUN QUERY
  veh_data <- as.data.table(dbGetQuery(caw_con, veh_qry))
  
  # FIELD TO IDENTIFY VEHICLES
  veh_data[, VIN_KEY:=paste0(trimws(VIN), trimws(VEH_MODL_YR))]
  
  # GET FIRST ROW FOR EACH VEHICLE
  veh_data <- veh_data[, .SD[1], by=.(ST_CD, PHYS_POL_KEY, VIN_KEY, VEH_STRT_DT, VEH_STOP_DT)]

  # REMOVE MULTIPLE VERSIONS THAT HAVE SAME START DATE
  # KEEP MAXIMUM STOP DATE
  veh_data <- veh_data[, .(VEH_STOP_DT=max(VEH_STOP_DT)), 
                       by=.(ST_CD, PHYS_POL_KEY, POL_STRT_DT, POL_STOP_DT, 
                            VIN_KEY, VEH_STRT_DT)]
  # REMOVE MULTIPLE VERSIONS THAT HAVE SAME STOP DATE
  # KEEP MINIMUM START DATE
  veh_data <- veh_data[, .(VEH_STRT_DT=min(VEH_STRT_DT)),
                       by=.(ST_CD, PHYS_POL_KEY, POL_STRT_DT, POL_STOP_DT,
                            VIN_KEY, VEH_STOP_DT)]
  
  # SORT DATA
  veh_data <- veh_data[order(ST_CD, PHYS_POL_KEY, VIN_KEY, VEH_STRT_DT, VEH_STOP_DT)]
  
  # GET START DATE OF NEXT VERSION FOR EACH DRIVER VERSION
  next_strt <- veh_data[, shift(VEH_STRT_DT, 1, type='lead'), by=.(ST_CD, PHYS_POL_KEY, VIN_KEY)]$V1
  veh_data[, NEXT_STRT:=next_strt]
  
  # GET MAXIMUM STOP DATE UP TO THAT POINT FOR EACH DRIVER VERSION
  veh_data[, MAX_STOP:=cummax(as.numeric(VEH_STOP_DT)), by=.(ST_CD, PHYS_POL_KEY, VIN_KEY)]
  
  # CALCULATE AND LABEL VERSIONS WHICH CHAIN TOGETHER OR OVERLAP
  veh_data[, CHAIN_ID:=c(0, cumsum(NEXT_STRT > MAX_STOP)[-.N]), by=.(ST_CD, PHYS_POL_KEY, VIN_KEY)]
  
  # GET RANGE FOR EACH DRIVER VERSION
  veh_data <- veh_data[, .(VEH_STRT_DT=min(VEH_STRT_DT),
                           VEH_STOP_DT=max(VEH_STOP_DT)),
                       by=.(ST_CD, PHYS_POL_KEY, VIN_KEY, CHAIN_ID, POL_STRT_DT, POL_STOP_DT)]
  
  # COUNT ADDITIONS AND DELETIONS
  veh_data[, VEH_ADD:=(VEH_STRT_DT>POL_STRT_DT)*1]
  veh_data[, VEH_REM:=(VEH_STOP_DT<POL_STOP_DT)*1]
  
  # SUMMARIZE DRIVER AND VEHICLE ENDORSEMENTS
  drv_data <- drv_data[, .(DRVR_ADDS=sum(DRVR_ADD), DRVR_REMS=sum(DRVR_REM)), by=.(ST_CD, PHYS_POL_KEY)]
  veh_data <- veh_data[, .(VEH_ADDS=sum(VEH_ADD), VEH_REMS=sum(VEH_REM)), by=.(ST_CD, PHYS_POL_KEY)]
  
  # MERGE (FULL OUTER JOIN) DRIVER AND VEHICLE ENDORSEMENTS
  eds_data <- merge(drv_data, veh_data, all=TRUE, by=c('ST_CD', 'PHYS_POL_KEY'))
  
  # COUNT ENDORSEMENTS
  eds_data[is.na(VEH_ADDS), VEH_ADDS:=0]
  eds_data[is.na(VEH_REMS), VEH_REMS:=0]
  eds_data[is.na(DRVR_ADDS), DRVR_ADDS:=0]
  eds_data[is.na(DRVR_REMS), DRVR_REMS:=0]
  eds_data[, PRIOR_TERM_EDS_CNT_OLD:=VEH_ADDS+VEH_REMS+DRVR_ADDS+DRVR_REMS]
  
  # POLICY QUERY
  pol_qry <- "
    SELECT 
    	CAW.POL_DATES.ST_CD, 
      CAW.POL_DATES.PHYS_POL_KEY, 
      CAW.POL_DATES.POL_ID_NBR, 
      CAW.POL_DATES.POL_EFF_DT,
      CAW.POLICY.COH_INCP_DT, 
      CAW.POLICY.RENW_CNT 
    FROM 
      CAW.POLICY, 
      CAW.POL_DATES 
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_STOP_DT BETWEEN {d 'start_date_minus_3yr'} AND {d 'end_date_plus_1yr'}
    ;
  "
  
  # REPLACE DATES IN QUERY
  pol_qry <- str_replace_all(pol_qry, 'start_date_minus_3yr', start_date_minus_3yr)
  pol_qry <- str_replace_all(pol_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # GET POLICY DATA
  pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  
  # JOIN POLICY DATA TO ENDORSEMENT DATA
  eds_data <- pol_data[eds_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # INCREMENT RENEWAL COUNT FOR JOINING TO NEXT POLICY TERM
  eds_data[, RENW_CNT:=RENW_CNT+1]
  eds_data <- eds_data[, .(ST_CD, POL_ID_NBR, COH_INCP_DT, RENW_CNT, PRIOR_TERM_EDS_CNT_OLD)]
  
  # GET PHYSICAL POLICY KEYS OF NEXT POLICY TERM
  eds_data <- merge(eds_data, pol_data, by=c('ST_CD', 'POL_ID_NBR', 'COH_INCP_DT', 'RENW_CNT'))
  eds_data <- eds_data[, .(ST_CD, PHYS_POL_KEY, PRIOR_TERM_EDS_CNT_OLD)]
  
  # JOIN TO BASE DATA
  base_data <- eds_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
