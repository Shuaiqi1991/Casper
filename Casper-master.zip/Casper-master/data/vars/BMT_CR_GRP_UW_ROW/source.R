library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BMT_CR_GRP_UW_ROW'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'CR_GRP_FLEET', 'UW_ROW')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[CR_GRP_FLEET %in% c("A","B"), CR_GRP_TEMP:="A/B"]
  base_data[CR_GRP_FLEET %in% c("C"), CR_GRP_TEMP:="C"]
  base_data[CR_GRP_FLEET %in% c("D","E"), CR_GRP_TEMP:="D/E"]
  base_data[is.na(CR_GRP_TEMP), CR_GRP_TEMP:="X"]
  
  base_data[UW_ROW==1, UW_ROW_TEMP:="1"]
  base_data[is.na(UW_ROW_TEMP), UW_ROW_TEMP:="2/3/4"]
  
  base_data[,BMT_CR_GRP_UW_ROW:=paste0(BMT_NO_LIV, "_", CR_GRP_TEMP, "_", UW_ROW_TEMP)]
  
  # DROP UNNECESSARY COLUMN
  base_data[,CR_GRP_TEMP:=NULL]
  base_data[,UW_ROW_TEMP:=NULL]
  
  # FORMAT
  base_data[,BMT_CR_GRP_UW_ROW:=as.factor(BMT_CR_GRP_UW_ROW)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
