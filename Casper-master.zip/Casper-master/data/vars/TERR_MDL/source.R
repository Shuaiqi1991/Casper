library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'TERR_MDL'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # DELETE EXISTING FIELDS, IF THEY EXIST
  if ('GRG_PSTL_CD' %in% names(base_data)) base_data[, GRG_PSTL_CD:=NULL]
  if ('TERR_DECILE' %in% names(base_data)) base_data[, TERR_DECILE:=NULL]
  if ('TERR_MDL' %in% names(base_data)) base_data[, TERR_MDL:=NULL]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # GARAGE POSTAL CODE QUERY
  zip_qry <- "
    SELECT DISTINCT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.GRG_PSTL_CD
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY, 
      CAW.VEHICLE 
    WHERE 
      CAW.VEHICLE.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    ;
  "
  # INSERT DATES INTO QUERY
  zip_qry <- str_replace_all(zip_qry, 'startdate', start_date)
  zip_qry <- str_replace_all(zip_qry, 'enddate', end_date)
  
  # RUN QUERY
  zip_data <- as.data.table(dbGetQuery(caw_con, zip_qry))
  
  # FORMATTING
  zip_data[, GRG_PSTL_CD:=trimws(GRG_PSTL_CD)]
  
  # ENSURE ONLY ONE ROW PER VEH KEY
  first_inds <- zip_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]$V1
  zip_data <- zip_data[first_inds]
  
  # JOIN ZIP ONTO BASE DATASET
  base_data <- zip_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # READ TERRITORY LOOKUP TABLE
  lookup_terr <- fread(here(var_lib_path, 'TERR_MDL', 'territory_deciles_2018.csv'))
  lookup_terr[, GRG_PSTL_CD:=str_pad(GRG_PSTL_CD, width=5, side='left', pad='0')]
  
  # LOOKUP TERRITORY DECILE
  base_data <- lookup_terr[base_data, on=.(GRG_PSTL_CD, BMT_NO_LIV)]
  
  # ASSIGN HI TO 1
  base_data[ST_CD=="52", TERR_DECILE:=1] #THIS IS A TEMPORARY ASSIGNMENT FOR 2019, WE WILL UPDATE LKUP TABLE FOR HI AND REMOVE THIS
  
  # NA HANDLING
  base_data[is.na(TERR_DECILE), TERR_DECILE:=0]
  
  # RENAME
  setnames(base_data, 'TERR_DECILE', 'TERR_MDL')
  
  # DROP COLUMNS
  base_data[, GRG_PSTL_CD:=NULL]
  
  # ENSURE FORMATTING
  base_data[, BMT_NO_LIV:=as.factor(BMT_NO_LIV)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
