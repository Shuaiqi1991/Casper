library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'V41_USDOT_SCR_GRPS'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # GET USDOT DATA
  usdot_data <- fread(here(var_lib_path, 'V41_USDOT_SCR_GRPS', 'bin', 'usdot_data.csv'),
                      colClasses=list(character=c('ST_CD', 'PHYS_POL_KEY')))
  
  # REMOVE DUPLICATES
  usdot_data <- usdot_data[order(ST_CD, PHYS_POL_KEY, V41_USDOT_SCR_GRPS)]
  first_inds <- usdot_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY)]$V1
  usdot_data <- usdot_data[first_inds]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('V41_USDOT_SCR_GRPS' %in% names(base_data)) base_data[, V41_USDOT_SCR_GRPS:=NULL]
  if ('CALC_LUSDOT_YRS' %in% names(base_data)) base_data[, CALC_LUSDOT_YRS:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- usdot_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMATTING
  usdot_grps <- usdot_data[, unique(V41_USDOT_SCR_GRPS)]
  base_data[! V41_USDOT_SCR_GRPS %in% usdot_grps, V41_USDOT_SCR_GRPS:='Z98']
  base_data[, V41_USDOT_SCR_GRPS:=as.factor(V41_USDOT_SCR_GRPS)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
