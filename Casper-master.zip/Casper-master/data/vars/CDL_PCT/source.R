library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'CDL_PCT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # DATES QUERY
  caw_qry <- "
    SELECT DISTINCT
      CAW.DRVR_DATES.ST_CD,
      CAW.DRVR_DATES.PHYS_POL_KEY,
      CAW.DRVR_DATES.PHYS_DRVR_KEY,
      CAW.DRVR_PUB_VIEW.CDL_CD,
      CAW.DRVR_PUB_VIEW.CDL_ISS_YR,
      CAW.POLICY.COH_INCP_DT
    FROM
      CAW.DRVR_DATES,
      CAW.POL_DATES,
      CAW.DRVR_PUB_VIEW,
      CAW.POLICY
    WHERE
      CAW.DRVR_DATES.ST_CD = CAW.POL_DATES.ST_CD
      AND CAW.DRVR_DATES.PHYS_POL_KEY = CAW.POL_DATES.PHYS_POL_KEY
      AND CAW.DRVR_DATES.ST_CD = CAW.POLICY.ST_CD
      AND CAW.DRVR_DATES.PHYS_POL_KEY = CAW.POLICY.PHYS_POL_KEY
      AND CAW.DRVR_DATES.ST_CD = CAW.DRVR_PUB_VIEW.ST_CD
      AND CAW.DRVR_DATES.PHYS_POL_KEY = CAW.DRVR_PUB_VIEW.PHYS_POL_KEY
      AND CAW.DRVR_DATES.PHYS_DRVR_KEY = CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.DRVR_DATES.DRVR_STRT_DT <> CAW.DRVR_DATES.DRVR_STOP_DT
      AND CAW.DRVR_DATES.DRVR_STRT_DT = CAW.DRVR_DATES.POL_STRT_DT
      AND CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND <> 'Y' 
      AND CAW.DRVR_PUB_VIEW.EXCL_IND <> 'Y'
  "
  # INSERT DATES INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # CDL DISCOUNT WITHOUT RENEWAL TREATMENT
  caw_data[, YR_DIFF:=lubridate::year(COH_INCP_DT)-CDL_ISS_YR]
  caw_data[, CDL_DISC_NO_RT:=ifelse(CDL_CD=='Y',
                                    ifelse(CDL_ISS_YR >= 1960,
                                           ifelse(YR_DIFF >= 2, 'Y', 'N'),
                                           'U'),
                                    ifelse(CDL_CD=='N', 'N', 'U'))]
  caw_data[, YR_DIFF:=NULL]

  # SORT DATA
  caw_data <- caw_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # CALCULATE % CDL AT POLICY LEVEL
  caw_data[, DRVR_PCT:=1/.N, by=.(ST_CD, PHYS_POL_KEY)]
  cdl_data <- dcast(caw_data, ST_CD + PHYS_POL_KEY ~ CDL_DISC_NO_RT, fun.aggregate=sum, value.var='DRVR_PCT')
  setnames(cdl_data, c('N', 'U', 'Y'), c('CDL_N_PCT', 'CDL_U_PCT', 'CDL_Y_PCT'))
  
  # CREATE NAMES COLUMN
  caw_data[, CDL_PCT_NAMES:='CDL_U_PCT']
  caw_data[CDL_DISC_NO_RT=='N', CDL_PCT_NAMES:='CDL_N_PCT']
  caw_data[CDL_DISC_NO_RT=='Y', CDL_PCT_NAMES:='CDL_Y_PCT']
  
  # DROP COLUMNS
  caw_data <- caw_data[, .(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, CDL_PCT_NAMES)]
  
  # BUSINESS USE QUERY
  bus_qry <- "
    SELECT DISTINCT
      CAW.POLICY.ST_CD,
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POLICY.BSNS_USE_CD
    FROM
      CAW.POLICY,
      CAW.POL_DATES
    WHERE
      CAW.POLICY.ST_CD = CAW.POL_DATES.ST_CD
      AND CAW.POLICY.PHYS_POL_KEY = CAW.POL_DATES.PHYS_POL_KEY
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
  "
  # INSERT DATES INTO QUERY
  bus_qry <- str_replace_all(bus_qry, 'startdate', start_date)
  bus_qry <- str_replace_all(bus_qry, 'enddate', end_date)
  
  # RUN QUERY
  bus_data <- as.data.table(dbGetQuery(caw_con, bus_qry))
  
  # DELETE EXISTING COLUMNS, IF ANY
  if ('CDL_PCT_NAMES' %in% names(base_data)) base_data[, CDL_PCT_NAMES:=NULL]
  if ('CDL_N_PCT' %in% names(base_data)) base_data[, CDL_N_PCT:=NULL]
  if ('CDL_U_PCT' %in% names(base_data)) base_data[, CDL_U_PCT:=NULL]
  if ('CDL_Y_PCT' %in% names(base_data)) base_data[, CDL_Y_PCT:=NULL]
  if ('BSNS_USE_CD' %in% names(base_data)) base_data[, BSNS_USE_CD:=NULL]
  
  # JOIN BUSINESS USE CODE TO BASE DATA
  base_data <- bus_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN CDL DATA TO BASE DATA
  base_data <- cdl_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN CDL NAMES TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # NA HANDLING
  base_data[is.na(CDL_PCT_NAMES), CDL_PCT_NAMES:='CDL_U_PCT']
  base_data[is.na(CDL_N_PCT), CDL_N_PCT:=0]
  base_data[is.na(CDL_U_PCT), CDL_U_PCT:=0]
  base_data[is.na(CDL_Y_PCT), CDL_Y_PCT:=0]
  base_data[CDL_N_PCT+CDL_U_PCT+CDL_Y_PCT==0, CDL_U_PCT:=1]
  
  # ISSUE WITH HOW THE DISCOUNTS ARE CODED FOR POLICIES PRIOR TO 5.X REVISIONS: PAQ ISSUE;
  base_data[BSNS_USE_CD=='A', CDL_PCT_NAMES:='CDL_U_PCT']
  base_data[BSNS_USE_CD=='A', CDL_N_PCT:=0]
  base_data[BSNS_USE_CD=='A', CDL_U_PCT:=1]
  base_data[BSNS_USE_CD=='A', CDL_Y_PCT:=0]
  base_data[, BSNS_USE_CD:=NULL]
  
  # FORMATTING
  base_data[CDL_PCT_NAMES=='CDL_N_PCT', CDL_DISC_NO_RT:='N']
  base_data[CDL_PCT_NAMES=='CDL_U_PCT', CDL_DISC_NO_RT:='U']
  base_data[CDL_PCT_NAMES=='CDL_Y_PCT', CDL_DISC_NO_RT:='Y']
  base_data[, CDL_DISC_NO_RT:=as.factor(CDL_DISC_NO_RT)]
  base_data[, CDL_PCT_NAMES:=as.factor(CDL_PCT_NAMES)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
