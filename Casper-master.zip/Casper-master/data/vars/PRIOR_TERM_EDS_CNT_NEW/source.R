library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PRIOR_TERM_EDS_CNT_NEW'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # POLICIES ABOUT TO WINK
  wnk_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.COH_INCP_DT,
      CAW.POLICY.RENW_CNT,
      CAW.POL_DATES.POL_EFF_DT, 
      CAW.POL_DATES.POL_EXPR_DT, 
      SUM(CAW.YEARLY_POL_PL.ERN_EXPS_CNT)/12 AS ECY
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY, 
      CAW.YEARLY_POL_PL 
    WHERE 
      CAW.YEARLY_POL_PL.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.YEARLY_POL_PL.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.YEARLY_POL_PL.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'start_date_minus_1yr'} AND {d 'end_date_plus_1yr'}
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.COH_INCP_DT,
      CAW.POLICY.RENW_CNT,
      CAW.POL_DATES.POL_EFF_DT, 
      CAW.POL_DATES.POL_EXPR_DT
  ;
  "
  
  # REPLACE DATES IN QUERY
  start_date_minus_1yr <- as.Date(start_date) %m+% lubridate::years(-1)
  start_date_minus_1yr <- as.character(start_date_minus_1yr)
  end_date_plus_1yr <- as.Date(end_date) %m+% lubridate::years(1)
  end_date_plus_1yr <- as.character(end_date_plus_1yr)
  wnk_qry <- str_replace_all(wnk_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  wnk_qry <- str_replace_all(wnk_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # RUN QUERY
  wnk_data <- as.data.table(dbGetQuery(caw_con, wnk_qry))
  
  # GET ENDORSEMENT DATA
  end_qry <- "
    SELECT
      CAI.ENDORSEMENT_ACTIVITY.*,
      DSE.STATE.ST_CD
    FROM
      CAI.ENDORSEMENT_ACTIVITY,
      DSE.STATE
    WHERE
      CAI.ENDORSEMENT_ACTIVITY.EFF_DT BETWEEN {d 'start_date_minus_1yr'} AND {d 'end_date_plus_1yr'}
      AND CAI.ENDORSEMENT_ACTIVITY.AS_IS_IND <> 'Y'
      AND CAI.ENDORSEMENT_ACTIVITY.END_TYPE IN ('Add Driver','Del Driver','Add Vehicle','Del Vehicle','Add Coverage','Del Coverage')
      AND CAI.ENDORSEMENT_ACTIVITY.DAYS_FR_EFF >= 0
      AND CAI.ENDORSEMENT_ACTIVITY.STATE = DSE.STATE.ALPHA_ST_CD
  "
  
  # REPLACE DATES IN QUERY
  end_qry <- str_replace_all(end_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  end_qry <- str_replace_all(end_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # RUN QUERY
  end_data <- as.data.table(dbGetQuery(caw_con, end_qry))
  
  # MERGE ENDORSEMENTS AND POLICY DATA
  setnames(end_data, c('POL_NBR', 'EFF_DT'), c('POL_ID_NBR', 'POL_EFF_DT'))
  end_data <- merge(wnk_data, end_data, by=c('ST_CD', 'POL_ID_NBR', 'POL_EFF_DT'))
  
  # FORMATTING
  end_data[, END_TYPE:=trimws(END_TYPE)]
  end_data[, RISK_POS:=as.integer(RISK_POS)]
  
  # POTENTIAL NTL ENDORSEMENTS
  ntl_ends <- end_data[END_TYPE %in% c('Add Vehicle','Del Vehicle','Add Coverage','Del Coverage')]
  
  # DRIVER ENDORSEMENTS
  drv_ends <- end_data[END_TYPE %in% c('Add Driver', 'Del Driver')]
  
  # VEHICLE ENDORSEMENTS
  veh_ends <- end_data[END_TYPE %in% c('Add Vehicle', 'Del Vehicle')]
  
  # GET POLICIES THAT HAD VEHICLE ENDORSEMENTS
  pol_veh_ends <- veh_ends[, .(ST_CD, PHYS_POL_KEY, POL_ID_NBR, POL_EFF_DT)]
  pol_veh_ends <- unique(pol_veh_ends)
  
  # GET BODY TYPES FOR THOSE POLICIES
  bt_qry <- "
    SELECT DISTINCT
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.VEH_BODY_TYP, 
      CAW.VEHICLE.VEH_POS_CNT, 
      CAW.VEHICLE.VIN, 
      CAW.VEHICLE.SYS_MOD_DT,
      CAW.BODYTYP.TRLR_OR_POWER 
    FROM 
      CAW.VEHICLE, 
      CAW.POL_DATES, 
      CAW.POLICY,
      CAW.BODYTYP
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.VEHICLE.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.VEHICLE.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.VEHICLE.POL_EXPR_YR 
      AND CAW.VEHICLE.VEH_BODY_TYP = CAW.BODYTYP.VEH_BODY_TYP
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'start_date_minus_1yr'} AND {d 'end_date_plus_1yr'}
    ;
  "
  
  # REPLACE DATES IN QUERY
  bt_qry <- str_replace_all(bt_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  bt_qry <- str_replace_all(bt_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # RUN QUERY
  bt_data <- as.data.table(dbGetQuery(caw_con, bt_qry))
  
  # JOIN BODY TYPES TO VEHICLE ENDORSEMENT POLICIES
  bt_data <- merge(bt_data, pol_veh_ends, by=c('ST_CD', 'PHYS_POL_KEY'))
  
  # SORT
  bt_data <- bt_data[order(ST_CD, PHYS_POL_KEY, VEH_POS_CNT, SYS_MOD_DT)]

  # GET MOST RECENT VERSION OF EACH VEHICLE
  bt_data <- bt_data[, .SD[.N], by=.(ST_CD, PHYS_POL_KEY, VEH_POS_CNT)]
  
  # REMOVE NON TRAILER NON POWER UNIT VALUES
  bt_data <- bt_data[TRLR_OR_POWER %in% c('T','P')]
  
  # JOIN BT DATA TO VEHICLE ENDORSEMENTS
  bt_data <- bt_data[, .(ST_CD, PHYS_POL_KEY, VEH_POS_CNT, TRLR_OR_POWER, VEH_BODY_TYP, VIN)]
  setnames(bt_data, 'VEH_POS_CNT', 'RISK_POS')
  veh_ends <- merge(bt_data, veh_ends, by=c('ST_CD', 'PHYS_POL_KEY', 'RISK_POS'))
  
  # CONCATENATE VEHICLE AND DRIVER ENDORSEMENTS
  veh_drv_ends <- rbindlist(list(veh_ends, drv_ends), use.names=TRUE, fill=TRUE)
  veh_drv_ends[is.na(TRLR_OR_POWER), TRLR_OR_POWER:='U']
  
  # ENDORSEMENT COUNTS
  veh_drv_ends[, VEH_EDS:=(END_TYPE %in% c('Add Vehicle', 'Del Vehicle'))*1]
  veh_drv_ends[, DRV_EDS:=(END_TYPE %in% c('Add Driver', 'Del Driver'))*1]
  veh_drv_ends[, TR_EDS:=ifelse(TRLR_OR_POWER=='T', VEH_EDS, 0)]
  veh_drv_ends[is.na(TR_EDS), TR_EDS:=0]
  eds_cnts <- veh_drv_ends[, .(RAW_EDS_CNT=.N,
                               RAW_EDS_CNT_DRVR=sum(DRV_EDS),
                               RAW_EDS_CNT_VEH=sum(VEH_EDS),
                               RAW_EDS_CNT_TR=sum(TR_EDS)),
                           by=.(ST_CD, PHYS_POL_KEY)]
  eds_cnts[, RAW_EDS_CNT_PU:=RAW_EDS_CNT_VEH-RAW_EDS_CNT_TR]
  
  ###########################################
  # DROPPING NTL AND SWTICHING TO LIABILITY #
  ###########################################  
  
  # EXTRACT QUALIFYING NTL ENDORSEMENT POLICIES
  ntl_pols <- ntl_ends[substr(CHG_FROM, 1, 4) %in% c('7110', '7210'), .(ST_CD, PHYS_POL_KEY)]
  ntl_pols <- unique(ntl_pols)
  
  # (INNER) JOIN VEHICLES TO POLICIES
  ntl_pols <- merge(bt_data, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY'))
  
  # (INNER) JOIN NTL ENDORSEMENTS TO VEHICLES
  ntl_pols <- merge(ntl_ends, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY', 'RISK_POS'))
  
  # CREATE NTL INDICATORS
  ntl_pols[, CHG_FROM:=trimws(CHG_FROM)]
  ntl_pols[, CHG_TO:=trimws(CHG_TO)]
  ntl_pols[, REM_NTL_IND:=(END_TYPE=='Del Coverage' &
                              substr(CHG_FROM, 1, 4) %in% c('7110', '7210') &
                              CHG_TO=='' &
                              TRLR_OR_POWER=='P')*1]
  ntl_pols[, ADD_LIAB_IND:=(END_TYPE=='Add Coverage' &
                             CHG_FROM=='' &
                             substr(CHG_TO, 1, 4) %in% c('1910','1983','1919','1901','1909','1908','2001','2004','2005','2009') &
                             TRLR_OR_POWER=='P')*1]
  ntl_pols[, ADD_TRL_IND:=(END_TYPE=='Add Vehicle' &
                             TRLR_OR_POWER=='T' &
                             VEH_BODY_TYP=='20')*1]
  
  # MAP NAs TO 0
  ntl_pols[is.na(REM_NTL_IND), REM_NTL_IND:=0]
  ntl_pols[is.na(ADD_LIAB_IND), ADD_LIAB_IND:=0]
  ntl_pols[is.na(ADD_TRL_IND), ADD_TRL_IND:=0]
  
  # FORMATTING OF RISK ATTRIBUTE
  ntl_pols[, RISK_ATTR:=trimws(RISK_ATTR)]

  # ROLL UP INDICATORS TO POLICY LEVEL
  ntl_roll_up <- ntl_pols[, lapply(.SD, sum), by=.(ST_CD, PHYS_POL_KEY, CHG_EFF_DT),
                          .SDcols=c('REM_NTL_IND', 'ADD_LIAB_IND', 'ADD_TRL_IND')]
  
  # FILTER ON: NTL DROPPED, LIABILITY ADDED, TRAILER ADDED
  ntl_roll_up <- ntl_roll_up[REM_NTL_IND>=1 & ADD_LIAB_IND>=1 & ADD_TRL_IND>=1]
  setnames(ntl_roll_up, 'ADD_TRL_IND', 'ADD_NTL_TRL')
  ntl_roll_up[, c('REM_NTL_IND', 'ADD_LIAB_IND'):=NULL]
  
  # FILTER (BY INNER JOIN) NTL ENDORSEMENTS
  # BY ENDORSEMENT DATES WHICH HAVE AN NTL DROP, LIAB ADD, AND TRAILER ADD
  ntl_roll_up <- ntl_roll_up[, .(ST_CD, PHYS_POL_KEY, CHG_EFF_DT)]
  ntl_roll_up <- merge(ntl_roll_up, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY', 'CHG_EFF_DT'))
  
  # FILTER ON ENDORSEMENTS WITH ONLY 1 TRAILER ADDED
  ntl_roll_up <- ntl_roll_up[ADD_TRL_IND==1]
  
  # GET UNIQUE VEHICLES AMONGST THESE ENDORSEMENTS
  ntl_roll_up <- ntl_roll_up[, .(ST_CD, PHYS_POL_KEY, RISK_POS, RISK_ATTR)]
  ntl_roll_up <- unique(ntl_roll_up)
  
  # FILTER (BY INNER JOIN) ENDORSEMENTS BY THESE VEHICLES
  ntl_drop <- merge(ntl_roll_up, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY', 'RISK_POS', 'RISK_ATTR'))
  
  ###########################################
  # DROPPING LIABILITY AND SWITCHING TO NTL #
  ###########################################
  
  # EXTRACT QUALIFYING NTL ENDORSEMENT POLICIES
  ntl_pols <- ntl_ends[substr(CHG_FROM, 1, 4) %in% c('7110', '7210'), .(ST_CD, PHYS_POL_KEY)]
  ntl_pols <- unique(ntl_pols)
  
  # JOIN BODY TYPE DATA TO POLICIES
  ntl_pols <- merge(bt_data, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY'))
  ntl_pols <- merge(ntl_ends, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY', 'RISK_POS'))
  
  # CREATE NTL INDICATORS
  ntl_pols[, CHG_FROM:=trimws(CHG_FROM)]
  ntl_pols[, CHG_TO:=trimws(CHG_TO)]
  ntl_pols[, REM_LIAB_IND:=(END_TYPE=='Del Coverage' &
                             substr(CHG_FROM, 1, 4) %in% c('1910','1983','1919','1901','1909','1908','2001','2004','2005','2009') &
                             CHG_TO=='' &
                             TRLR_OR_POWER=='P')*1]
  ntl_pols[, ADD_NTL_IND:=(END_TYPE=='Add Coverage' &
                              CHG_FROM=='' &
                              substr(CHG_TO, 1, 4) %in% c('7110', '7210') &
                              TRLR_OR_POWER=='P')*1]
  ntl_pols[, DEL_TRL_IND:=(END_TYPE=='Del Vehicle' &
                             TRLR_OR_POWER=='T')*1]
  
  # MAP NAs TO 0
  ntl_pols[is.na(ADD_NTL_IND), ADD_NTL_IND:=0]
  ntl_pols[is.na(REM_LIAB_IND), REM_LIAB_IND:=0]
  ntl_pols[is.na(DEL_TRL_IND), DEL_TRL_IND:=0]
  
  # ROLL UP INDICATORS TO POLICY LEVEL
  ntl_roll_up <- ntl_pols[, lapply(.SD, sum), by=.(ST_CD, PHYS_POL_KEY, CHG_EFF_DT),
                          .SDcols=c('REM_LIAB_IND', 'ADD_NTL_IND', 'DEL_TRL_IND')]
  
  # FILTER ON: NTL ADDED, LIABILITY DROPPED, TRAILER REMOVED
  ntl_roll_up <- ntl_roll_up[ADD_NTL_IND>=1 & REM_LIAB_IND>=1 & DEL_TRL_IND>=1]
  setnames(ntl_roll_up, 'DEL_TRL_IND', 'DEL_NTL_TRLR')
  ntl_roll_up[, c('ADD_NTL_IND', 'REM_LIAB_IND'):=NULL]
  
  # FILTER (BY INNER JOIN) NTL ENDORSEMENTS
  # BY ENDORSEMENT DATES WHICH HAVE AN NTL ADD, LIAB DROP, AND TRAILER DROP
  ntl_roll_up <- ntl_roll_up[, .(ST_CD, PHYS_POL_KEY, CHG_EFF_DT)]
  ntl_roll_up <- merge(ntl_roll_up, ntl_pols, by=c('ST_CD', 'PHYS_POL_KEY', 'CHG_EFF_DT'))
  
  # FILTER ON ENDORSEMENTS WITH ONLY 1 TRAILER DROPPED
  ntl_roll_up <- ntl_roll_up[DEL_TRL_IND==1]
  
  # DROP UNNEEDED COLUMNS
  ntl_add <- ntl_roll_up[, -c('ADD_NTL_IND', 'REM_LIAB_IND', 'DEL_TRL_IND')]
  
  # MERGE NTL DROPS AND ADDS
  ntl_data <- rbindlist(list(ntl_drop, ntl_add), use.names=TRUE, fill=TRUE)
  
  # REMOVE DUPLICATES IF ANY
  ntl_data <- ntl_data[order(ST_CD, PHYS_POL_KEY, RISK_POS, RISK_ATTR, CHG_EFF_DT, TRAN_DT)]
  ntl_data <- ntl_data[, .SD[1], by=.(ST_CD, PHYS_POL_KEY, RISK_POS, RISK_ATTR, CHG_EFF_DT, TRAN_DT)]
  
  # FIX ISSUE WITH MULTIPLE RISK POSITION NUMBERS FOR THE SAME RISK ATTRIBUTE ON SAME EFFECTIVE DATE
  veh_drv_ends[, N_POS:=uniqueN(RISK_POS), by=.(ST_CD, PHYS_POL_KEY, CHG_EFF_DT, RISK_ATTR)]
  mult_pos_data <- veh_drv_ends[N_POS>1]
  mult_pos_data <- mult_pos_data[, .(ST_CD, PHYS_POL_KEY, CHG_EFF_DT, TRAN_DT, RISK_POS, RISK_ATTR, END_TYPE, TRLR_OR_POWER)]
  mult_pos_data <- unique(mult_pos_data)
  
  # SPLIT INTO VEHICLE AND DRIVER ENDORSEMENTS
  veh_data <- mult_pos_data[END_TYPE %in% c('Add Vehicle', 'Del Vehicle')]
  drv_data <- mult_pos_data[END_TYPE %in% c('Add Driver', 'Del Driver')]
  
  # REMOVING NTL ENDORSEMENTS
  cols <- c('ST_CD', 'PHYS_POL_KEY', 'RISK_ATTR', 'RISK_POS', 'END_TYPE', 'CHG_EFF_DT', 'TRAN_DT')
  ntl_data_sub <- ntl_data[, cols, with=F]
  ntl_data_sub <- merge(veh_data, ntl_data_sub, by=cols)
  ntl_data_sub <- ntl_data_sub[, .(ST_CD, PHYS_POL_KEY, CHG_EFF_DT, TRAN_DT, RISK_ATTR, RISK_POS, END_TYPE)]
  ntl_data_sub[, IND:=1]
  veh_data <- ntl_data_sub[veh_data, on=.(ST_CD, PHYS_POL_KEY, CHG_EFF_DT, TRAN_DT, RISK_ATTR, RISK_POS, END_TYPE)]
  veh_data[is.na(IND), IND:=0]
  ntl_veh_data <- veh_data[IND==1]
  veh_data <- veh_data[IND==0]
  
  # COUNTING ENDORSEMENTS
  cnt_data <- rbindlist(list(veh_data, drv_data), use.names=TRUE, fill=TRUE)
  adds <- cnt_data[END_TYPE %in% c('Add Driver', 'Add Vehicle'), 
                   .(ADD=.N), by=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  dels <- cnt_data[END_TYPE %in% c('Del Driver', 'Del Vehicle'), 
                   .(DEL=.N), by=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  
  # CREATE ADDITION DELETION INDICATORS
  veh_data[, ADD_IND:=(END_TYPE=='Add Vehicle')*1]
  veh_data[, DEL_IND:=(END_TYPE=='Del Vehicle')*1]
  veh_data[, TRL_IND:=(TRLR_OR_POWER=='T')*1]
  veh_data[, PU_IND:=(TRLR_OR_POWER=='P')*1]
  
  # SUM INDICATORS TO RISK LEVEL
  veh_sum_data <- veh_data[, lapply(.SD, sum), by=.(ST_CD, PHYS_POL_KEY, CHG_EFF_DT, RISK_ATTR),
                           .SDcols=c('ADD_IND', 'DEL_IND', 'TRL_IND', 'PU_IND')]
  
  veh_sum_data[, REM_TRLR:=ifelse(ADD_IND==DEL_IND, TRL_IND,
                                  floor(2 * pmin(ADD_IND, DEL_IND) * TRL_IND / (TRL_IND + PU_IND)))]
  veh_sum_data[, REM_PU:=ifelse(ADD_IND==DEL_IND, PU_IND,
                                2 * pmin(ADD_IND, DEL_IND) - REM_TRLR)]
  
  # DRIVER
  add_drvrs <- drv_data[END_TYPE=='Add Driver', .(DRVR_ADD_CNT=.N),
                        by=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  del_drvrs <- drv_data[END_TYPE=='Del Driver', .(DRVR_DEL_CNT=.N),
                        by=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  
  # TOTAL COUNT
  total_cnts <- cnt_data[, .(TOTAL_CNT=.N), by=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  total_cnts <- add_drvrs[total_cnts, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  total_cnts <- del_drvrs[total_cnts, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  total_cnts <- adds[total_cnts, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  total_cnts <- dels[total_cnts, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  total_cnts <- veh_sum_data[total_cnts, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT)]
  
  # DELETE UNNECESSARY DATA
  objs <- c('add_drvrs', 'del_drvrs', 'adds', 'dels', 'veh_sum_data')
  rm(list=objs)
  
  # MAP NAs TO 0
  cnts <- setdiff(names(total_cnts), c('ST_CD', 'PHYS_POL_KEY', 'RISK_ATTR', 'CHG_EFF_DT'))
  for (j in cnts) set(total_cnts, j=j, value=ifelse(is.na(total_cnts[[j]]), 0, total_cnts[[j]]))
  
  # GET TOTAL COUNTS
  total_cnts[, REM:=ADD+DEL-abs(ADD-DEL)]
  total_cnts[, REM_DRVR:=DRVR_ADD_CNT+DRVR_DEL_CNT-abs(DRVR_ADD_CNT-DRVR_DEL_CNT)]
  total_cnts <- total_cnts[, .(ST_CD, PHYS_POL_KEY, RISK_ATTR, CHG_EFF_DT, 
                               REM, REM_DRVR, REM_TRLR, REM_PU)]
  
  # GET FORGIVEABLE NTL COUNTS
  ntl_veh_data <- ntl_veh_data[, .(ST_CD, PHYS_POL_KEY, RISK_ATTR, RISK_POS,
                                   CHG_EFF_DT, TRAN_DT, END_TYPE)]
  ntl_veh_data[, IND:=1]
  ntl_forgive <- ntl_veh_data[ntl_data, on=.(ST_CD, PHYS_POL_KEY, RISK_ATTR, RISK_POS,
                                             CHG_EFF_DT, TRAN_DT, END_TYPE)]
  ntl_forgive[is.na(IND), IND:=0]
  ntl_forgive <- ntl_forgive[IND!=1]
  ntl_forgive <- ntl_forgive[, .(REM_NTL=.N), by=.(ST_CD, PHYS_POL_KEY)]
  
  # GET FORGIVEABLE DATA ISSUE COUNTS
  dt_forgive <- total_cnts[, lapply(.SD, sum), by=.(ST_CD, PHYS_POL_KEY),
                           .SDcols=c('REM', 'REM_DRVR', 'REM_TRLR', 'REM_PU')]
  
  # GET OVERLAPPING COUNTS
  both_forgive <- ntl_veh_data[, .(REM_BOTH=.N), by=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN ALL DATA
  eds_cnts <- eds_cnts[, .(ST_CD, PHYS_POL_KEY, RAW_EDS_CNT, RAW_EDS_CNT_DRVR, 
                           RAW_EDS_CNT_TR, RAW_EDS_CNT_PU)]
  pol_cols <- c('ST_CD', 'PHYS_POL_KEY', 'POL_ID_NBR', 'COH_INCP_DT', 'RENW_CNT')
  wnk_data <- wnk_data[, pol_cols, with=F]
  pol_data <- eds_cnts[wnk_data, on=.(ST_CD, PHYS_POL_KEY)]
  pol_data <- both_forgive[pol_data, on=.(ST_CD, PHYS_POL_KEY)]
  pol_data <- ntl_forgive[pol_data, on=.(ST_CD, PHYS_POL_KEY)]
  pol_data <- dt_forgive[pol_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # DELETE UNECESSARY DATA
  objs <- c('wnk_data', 'eds_cnts', 'both_forgive', 'ntl_forgive', 'dt_forgive')
  rm(list=objs)
  
  # MAP NAs TO 0
  stats <- setdiff(names(pol_data), pol_cols)
  for (j in stats) set(pol_data, j=j, value=ifelse(is.na(pol_data[[j]]), 0, pol_data[[j]]))
  
  # INCREMENT RENEWAL COUNT TO 1 SO THAT WE CAN JOIN THE SUCCEEDING POLICY TO IT
  # ENDORSEMENT COUNTS BECOME PRIOR TERM ENDORSEMENT COUNTS
  pol_data[, RENW_CNT:=RENW_CNT+1]
  pol_data[, PHYS_POL_KEY:=NULL]
  
  # GET SUCCEEDING POLICIES
  pol_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.COH_INCP_DT, 
      CAW.POLICY.RENW_CNT, 
      CAW.POLICY.PHYS_POL_KEY 
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'start_date_minus_1yr'} AND {d 'end_date_plus_1yr'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    ;
  "
  
  # REPLACE DATES IN QUERY
  pol_qry <- str_replace_all(pol_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  pol_qry <- str_replace_all(pol_qry, 'end_date_plus_1yr', end_date_plus_1yr)
  
  # GET SUCCEEDING POLICIES
  next_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  
  # JOIN PHYSICAL POLICY KEYS
  final_eds_data <- merge(pol_data, next_data, by=c('ST_CD', 'POL_ID_NBR', 'COH_INCP_DT', 'RENW_CNT'))
  rm(pol_data)
  rm(next_data)
  
  # CREATE PRIOR TERM ENDORSEMENT COUNTS
  #final_eds_data[, PRIOR_TERM_EDS_NEW:=RAW_EDS_CNT - REM_BOTH - REM_NTL - REM]
  #final_eds_data[, PRIOR_TERM_EDS_NEW_DRVR:=RAW_EDS_CNT_DRVR - REM_DRVR]
  #final_eds_data[, PRIOR_TERM_EDS_NEW_TR:=RAW_EDS_CNT_TR - REM_TRLR - REM_BOTH - REM_NTL]
  #final_eds_data[, PRIOR_TERM_EDS_NEW_PU:=RAW_EDS_CNT_PU - REM_PU]
  final_eds_data[, PRIOR_TERM_EDS_CNT_NEW:=RAW_EDS_CNT_PU - REM_PU + RAW_EDS_CNT_DRVR - REM_DRVR]
  final_eds_data <- final_eds_data[, .(ST_CD, PHYS_POL_KEY, PRIOR_TERM_EDS_CNT_NEW)]
  
  # JOIN TO BASE DATA
  base_data <- final_eds_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
