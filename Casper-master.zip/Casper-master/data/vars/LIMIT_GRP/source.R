library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'LIMIT_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # LOOKUP TABLES
  lookup_bi_csl <- fread(here(var_lib_path, 'LIMIT_GRP', 'lookup_bi_csl.csv'))
  lookup_st_bi_csl <- fread(here(var_lib_path, 'LIMIT_GRP', 'lookup_st_bi_csl.csv'))
  lookup_pd_csl <- fread(here(var_lib_path, 'LIMIT_GRP', 'lookup_pd_csl.csv'))
  lookup_st_pd_csl <- fread(here(var_lib_path, 'LIMIT_GRP', 'lookup_st_pd_csl.csv'))
  lookup_limit_grp <- fread(here(var_lib_path, 'LIMIT_GRP', 'lookup_limit_grp.csv'))
  
  # FORMAT LOOKUPS
  lookup_bi_csl[, BI_LCL:=as.character(BI_LCL)]
  lookup_pd_csl[, PD_LCL:=as.character(PD_LCL)]
  lookup_st_bi_csl[, BI_LCL:=as.character(BI_LCL)]
  lookup_st_pd_csl[, PD_LCL:=as.character(PD_LCL)]
  lookup_st_bi_csl[, ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  lookup_st_pd_csl[, ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  lookup_st_pd_csl[, ST_PD_SINGLE:=as.numeric(ST_PD_SINGLE)]
  
  # LOOKUP CSL
  base_data <- lookup_bi_csl[base_data, on=.(BI_LCL)]
  base_data <- lookup_pd_csl[base_data, on=.(PD_LCL)]
  base_data <- lookup_st_bi_csl[base_data, on=.(ST_CD, BI_LCL)]
  base_data <- lookup_st_pd_csl[base_data, on=.(ST_CD, PD_LCL)]
  base_data[!is.na(ST_PD_SINGLE), PD_SINGLE:=ST_PD_SINGLE]
  base_data[!is.na(ST_BI_SINGLE), BI_SINGLE:=ST_BI_SINGLE]
  base_data[!is.na(ST_BI_SINGLE), BI_ACC:=ST_BI_ACC]
  
  # CREATE BIPD CSL
  base_data[, BIPD_CSL:=0.45*BI_SINGLE+0.50*BI_ACC+0.15*PD_SINGLE]
  base_data[is.na(BI_ACC) & is.na(BI_SINGLE), BIPD_CSL:=PD_SINGLE]
  base_data[is.na(BI_ACC) & !is.na(BI_SINGLE), BIPD_CSL:=BI_SINGLE]
  
  # PUT NAs WITH BIPD CSL 100K
  base_data[is.na(BIPD_CSL), BIPD_CSL:=100]
  
  # JOIN LIMIT GROUP
  base_data <- lookup_limit_grp[base_data, on=.(BIPD_CSL), roll=T]

  # CREATE GRANULAR LIMIT GROUP
  base_data[, LIMIT_GRP:=as.factor(LIMIT_GRP)]
  base_data[, LIMIT_GRP_DESC:=as.factor(LIMIT_GRP_DESC)]
  
  # DROP UNNECESSARY COLUMNS
  drop_cols <- c('ST_PD_SINGLE', 'ST_BI_SINGLE', 'ST_BI_ACC', 'PD_SINGLE', 'BI_SINGLE', 'BI_ACC')
  base_data <- base_data[, -c(drop_cols), with=F]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
