library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'POWER_UNIT_CNT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN POLICIES
  puc_qry <- "
    SELECT
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY,
    	CAW.POLICY.POWER_UNIT_CNT
    FROM 
      CAW.POLICY, 
      CAW.POL_DATES 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      and CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      and CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      and CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POLICY.POWER_UNIT_CNT
    ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  puc_qry <- str_replace_all(puc_qry, 'startdate', start_date)
  puc_qry <- str_replace_all(puc_qry, 'enddate', end_date)
  
  # RUN QUERIES
  puc_data <- as.data.table(dbGetQuery(caw_con, puc_qry))

  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('POWER_UNIT_CNT' %in% names(base_data)) base_data[, POWER_UNIT_CNT:=NULL]

  # JOIN POWER UNIT CNT ONTO BASE DATASET
  base_data <- puc_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}