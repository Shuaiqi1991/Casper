library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'PLA_CNT_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # FEATURE QUERY
  clm_qry <- "
    SELECT
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.RENW_SFX_NBR, 
      CAW.POLICY.COH_INCP_DT, 
      CAW.POLICY.SIC_CD, 
      CAW.POL_DATES.POL_EFF_DT, 
      CAW.POL_DATES.POL_EXPR_DT,
      CAW.CLM_FEA.LRD_STMP_DT_YR,
      CAW.CLM_FEA.CLM_NBR, 
      CAW.CLM_FEA.FEA_SEQ_NBR, 
      CAW.CLM_FEA.VEH_POS_CNT,
      CAW.CLM_FEA.DRVR_POS_CNT,
      CAW.CLM_FEA.LINE_COV_CD,
      CAW.CLM_FEA.LIM_CD,
      CAW.MNTHLY_LOSS.ACC_DT,
      MAX(CAW.MNTHLY_LOSS.SYS_MOD_DT) AS SYS_MOD_DT,
      SUM(CAW.MNTHLY_LOSS.LOSS_PAID_AMT - CAW.MNTHLY_LOSS.LOSS_SLSB_AMT) AS NET_PAID, 
    	SUM(CAW.MNTHLY_LOSS.LOSS_SLSB_AMT) AS SLSB
    FROM 
      CAW.CLM_FEA,
      CAW.POL_DATES, 
      CAW.POLICY,
      CAW.MNTHLY_LOSS
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.CLM_FEA.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.CLM_FEA.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.CLM_FEA.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EXPR_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.CLM_FEA.FEA_CLOS_DT IS NOT NULL
      AND CAW.MNTHLY_LOSS.ST_CD = CAW.CLM_FEA.ST_CD
      AND CAW.MNTHLY_LOSS.PHYS_POL_KEY = CAW.CLM_FEA.PHYS_POL_KEY
      AND CAW.MNTHLY_LOSS.CLM_NBR = CAW.CLM_FEA.CLM_NBR
      AND CAW.MNTHLY_LOSS.FEA_SEQ_NBR = CAW.CLM_FEA.FEA_SEQ_NBR
      AND CAW.MNTHLY_LOSS.VEH_POS_CNT = CAW.CLM_FEA.VEH_POS_CNT
      AND CAW.MNTHLY_LOSS.DRVR_POS_CNT = CAW.CLM_FEA.DRVR_POS_CNT
      AND CAW.MNTHLY_LOSS.LINE_COV_CD = CAW.CLM_FEA.LINE_COV_CD
      AND CAW.MNTHLY_LOSS.LIM_CD = CAW.CLM_FEA.LIM_CD
      AND CAW.MNTHLY_LOSS.FEA_SEQ_NBR <> 0
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.RENW_SFX_NBR, 
      CAW.POLICY.COH_INCP_DT, 
      CAW.POLICY.SIC_CD, 
      CAW.POL_DATES.POL_EFF_DT, 
      CAW.POL_DATES.POL_EXPR_DT,
      CAW.CLM_FEA.LRD_STMP_DT_YR,
      CAW.CLM_FEA.CLM_NBR, 
      CAW.CLM_FEA.FEA_SEQ_NBR, 
      CAW.CLM_FEA.VEH_POS_CNT,
      CAW.CLM_FEA.DRVR_POS_CNT,
      CAW.CLM_FEA.LINE_COV_CD,
      CAW.CLM_FEA.LIM_CD,
      CAW.MNTHLY_LOSS.ACC_DT
  "
  # INSERT DATES INTO QUERY
  new_start_date <- as.Date(start_date)
  new_start_date <- new_start_date %m+% years(-3)
  new_start_date <- as.character(new_start_date)
  new_end_date <- as.Date(end_date)
  new_end_date <- new_end_date %m+% years(1)
  new_end_date <- as.character(new_end_date)
  clm_qry <- str_replace_all(clm_qry, 'startdate', new_start_date)
  clm_qry <- str_replace_all(clm_qry, 'enddate', new_end_date)
  
  # RUN QUERY
  clm_data <- as.data.table(dbGetQuery(caw_con, clm_qry))
  
  # SORT, GET MOST RECENT RECORD FOR EACH FEATURE
  clm_data <- clm_data[order(ST_CD, PHYS_POL_KEY, CLM_NBR, FEA_SEQ_NBR, -SYS_MOD_DT, -NET_PAID)]
  first_inds <- clm_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, CLM_NBR, FEA_SEQ_NBR)]$V1
  clm_data <- clm_data[first_inds]
  
  # LOOKUP LCG
  lookup_lcg <- fread(here(var_lib_path, 'PLA_CNT_GRP', 'lookup_lcg.csv'))
  lookup_lcg[, LINE_COV_CD:=str_pad(LINE_COV_CD, width=4, side='left', pad='0')]
  clm_data <- clm_data[! LINE_COV_CD %in% c('1713', '1752', '1761', '1771', '1772', '1775')]
  clm_data <- lookup_lcg[clm_data, on=.(LINE_COV_CD)]
  clm_data[is.na(LCG), LCG:='OTHER']
  
  # CREATE COVERAGE-SPECIFIC LOSS COLUMNS
  clm_data[, BI_CLS_PAID:=ifelse(LCG=='BI', NET_PAID, 0)]
  clm_data[, PD_CLS_PAID:=ifelse(LCG=='PD', NET_PAID, 0)]
  clm_data[, COLL_CLS_PAID:=ifelse(LCG=='COLL', NET_PAID, 0)]
  clm_data[, BIPD_COLL_CLS_PAID:=BI_CLS_PAID+PD_CLS_PAID+COLL_CLS_PAID]

  clm_data[, BI_CLS_SLSB:=ifelse(LCG=='BI', SLSB, 0)]
  clm_data[, PD_CLS_SLSB:=ifelse(LCG=='PD', SLSB, 0)]
  clm_data[, COLL_CLS_SLSB:=ifelse(LCG=='COLL', SLSB, 0)]
  clm_data[, BIPD_COLL_CLS_SLSB:=BI_CLS_SLSB+PD_CLS_SLSB+COLL_CLS_SLSB]
  
  # CREATE INDICATOR FOR NON-PD, NON-COLL CLAIMS
  clm_data[, NON_PD_COLL_CNT:=ifelse(! LCG %in% c('PD', 'COLL'), 1, 0)]
  
  # ROLL UP TO CLAIM LEVEL
  sum_cols <- c('BI_CLS_PAID', 'PD_CLS_PAID', 'COLL_CLS_PAID', 'BIPD_COLL_CLS_PAID',
                'BI_CLS_SLSB', 'PD_CLS_SLSB', 'COLL_CLS_SLSB', 'BIPD_COLL_CLS_SLSB',
                'NON_PD_COLL_CNT')
  by_cols <- c('ST_CD', 'PHYS_POL_KEY', 'POL_ID_NBR', 'POL_EXPR_DT', 'POL_EFF_DT',
               'COH_INCP_DT', 'SIC_CD', 'CLM_NBR', 'LRD_STMP_DT_YR', 'ACC_DT')
  clm_data <- clm_data[, lapply(.SD, sum), by=c(by_cols), .SDcols=c(sum_cols)]
  
  # FLAG PD/COLL ONLY CLAIMS
  clm_data[, PD_COLL_ONLY:=ifelse(NON_PD_COLL_CNT>0, 'N', 'Y')]
  clm_data[, NON_PD_COLL_CNT:=NULL]
  
  # LRD QUERY
  lrd_qry <- "
    SELECT DISTINCT
      LRD.CLMPRTY.PRTY_REC_SEQ_NBR,
    	LRD.CLMPRTY.PRTY_CLM_CNTCT_DT,
      LRD.CLMPRTY.LST_UPDT_DT, 
      LRD.CLMPRTY.CLM_PRTY_LIAB_PCT,
      LRD.CLMPRTY.CPU_STMP_DT_YR,
      LRD.CLMPRTY.CLM_NBR
    FROM
      LRD.CLMPRTY
    WHERE
      LRD.CLMPRTY.PRTY_TYP_CD in ('003', '004')
  "
  # INSERT DATES INTO QUERY
  lrd_qry <- str_replace_all(lrd_qry, 'startdate', new_start_date)
  
  # RUN QUERY
  lrd_data <- as.data.table(dbGetQuery(caw_con, lrd_qry))
  
  # FILTER ON CLAIM DATASET
  lrd_data <- lrd_data[clm_data[, .(ST_CD, PHYS_POL_KEY, CLM_NBR, CPU_STMP_DT_YR=LRD_STMP_DT_YR)],
                       on=.(CLM_NBR, CPU_STMP_DT_YR)]
  
  # SORT, GET MOST RECENT RECORD FOR EACH CLAIM & SEQ NBR
  lrd_data <- lrd_data[order(PHYS_POL_KEY, CPU_STMP_DT_YR, CLM_NBR, PRTY_REC_SEQ_NBR, LST_UPDT_DT)]
  last_inds <- lrd_data[, .I[.N], by=.(PHYS_POL_KEY, CPU_STMP_DT_YR, CLM_NBR, PRTY_REC_SEQ_NBR)]$V1
  lrd_data <- lrd_data[last_inds]
  
  # SUM UP LIABILITY ACROSS ALL INSURED PARTIES
  sum_cols <- c('CLM_PRTY_LIAB_PCT')
  by_cols <- c('ST_CD', 'PHYS_POL_KEY', 'CLM_NBR', 'CPU_STMP_DT_YR')
  lrd_data <- lrd_data[, lapply(.SD, sum), by=c(by_cols), .SDcols=c(sum_cols)]
  
  # MERGE WITH CLAIM DATA
  setnames(lrd_data, 'CPU_STMP_DT_YR', 'LRD_STMP_DT_YR')
  clm_data <- merge(clm_data, lrd_data, by=c('ST_CD', 'PHYS_POL_KEY', 'CLM_NBR', 'LRD_STMP_DT_YR'))
  
  # FILTER ON LIABILITY > 0% AND PAID >= $500
  clm_data <- clm_data[BIPD_COLL_CLS_PAID>=500 & CLM_PRTY_LIAB_PCT>0]
  
  # GET FIRST RECORD FOR EACH CLAIM
  clm_data <- clm_data[order(ST_CD, PHYS_POL_KEY, CLM_NBR, ACC_DT)]
  first_inds <- clm_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, CLM_NBR)]$V1
  clm_data <- clm_data[first_inds]
  
  # POLICY LIST
  pol_qry <- "
    SELECT
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POL_DATES.POL_EFF_DT,
      CAW.POLICY.COH_INCP_DT
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EXPR_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
  "
  
  # INSERT DATES INTO QUERY
  pol_qry <- str_replace_all(pol_qry, 'startdate', new_start_date)
  pol_qry <- str_replace_all(pol_qry, 'enddate', new_end_date)
  
  # RUN QUERY
  pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  clm_data <- clm_data[, .(ST_CD, POL_ID_NBR, CLM_NBR, COH_INCP_DT, ACC_DT)]
  
  # JOIN CLAIMS TO POLICIES SO WE CAN COUNT NUMBER OF CLAIMS OCCURRING IN PRIOR TERMS/YEARS
  clm_data <- merge(clm_data, pol_data, by=c('ST_CD', 'POL_ID_NBR', 'COH_INCP_DT'))
  
  # ONLY COUNT CLAIMS THAT ARE FROM DIFFERENT TERMS AND ACCIDENT DATE <= POL_EFF_DT
  clm_data <- clm_data[ACC_DT<=POL_EFF_DT]
  
  # CALCULATE TERM LENGTH
  #clm_data[, TERM_LENGTH:=as.integer(POL_EXPR_DT-POL_EFF_DT)]
  
  # COUNT 3 YR AAFs, 5 YR AAFs, AND PRIOR TERM AAFs
  clm_data <- clm_data[, .(AAF_3YR=sum(POL_EFF_DT-ACC_DT<=1095)), by=.(ST_CD, PHYS_POL_KEY)]
  # clm_data <- clm_data[, .(AAF_3YR=sum(POL_EFF_DT-ACC_DT<=1095),
  #                          AAF_5YR=sum(POL_EFF_DT-ACC_DT<=1826),
  #                          AAF_PRIOR_TERM=ifelse(TERM_LENGTH>=360,
  #                                                sum(POL_EFF_DT-ACC_DT<=365),
  #                                                sum(POL_EFF_DT-ACC_DT<=180))),
  #                      by=.(ST_CD, PHYS_POL_KEY)]
  
  # VIOLATIONS QUERY
  vio_qry <- "
    SELECT DISTINCT
      CAW.DRIVER_VIOL.ST_CD, 
      CAW.DRIVER_VIOL.PHYS_POL_KEY, 
      CAW.POL_DATES.POL_EFF_DT,
      CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
      CAW.DRIVER_VIOL.VIOL_CD, 
      CAW.DRIVER_VIOL.DRVR_INCID_DT, 
      CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
    FROM
      CAW.DRIVER_VIOL,
      CAW.POL_DATES
    WHERE
      CAW.DRIVER_VIOL.ST_CD = CAW.POL_DATES.ST_CD 
      AND CAW.DRIVER_VIOL.PHYS_POL_KEY = CAW.POL_DATES.PHYS_POL_KEY
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
  "
  # INSERT DATES INTO QUERY
  vio_qry <- str_replace_all(vio_qry, 'startdate', start_date)
  vio_qry <- str_replace_all(vio_qry, 'enddate', end_date)
  
  # RUN QUERY
  vio_data <- as.data.table(dbGetQuery(caw_con, vio_qry))
  
  # DATES QUERY
  dts_qry <- "
    SELECT DISTINCT
      CAW.DRVR_DATES.ST_CD,
      CAW.DRVR_DATES.PHYS_POL_KEY,
      CAW.DRVR_DATES.PHYS_DRVR_KEY,
      CAW.DRVR_DATES.DRVR_POS_CNT,
      CAW.DRVR_DATES.DRVR_STRT_DT
    FROM
      CAW.DRVR_DATES,
      CAW.POL_DATES
    WHERE
      CAW.DRVR_DATES.ST_CD = CAW.POL_DATES.ST_CD 
      AND CAW.DRVR_DATES.PHYS_POL_KEY = CAW.POL_DATES.PHYS_POL_KEY
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
  "
  # INSERT DATES INTO QUERY
  dts_qry <- str_replace_all(dts_qry, 'startdate', start_date)
  dts_qry <- str_replace_all(dts_qry, 'enddate', end_date)
  
  # RUN QUERY
  dts_data <- as.data.table(dbGetQuery(caw_con, dts_qry))
  
  # SORT DRIVER DATES, GET FIRST START DATE FOR EACH DRIVER POSITION COUNT
  dts_data <- dts_data[order(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT, DRVR_STRT_DT)]
  first_inds <- dts_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
  dts_data <- dts_data[first_inds]
  
  # MERGE DATES AND VIOLATIONS
  vio_data <- dts_data[vio_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # USE POL EFF DT FOR MISSING DRIVER DATES
  vio_data[is.na(DRVR_STRT_DT), DRVR_STRT_DT:=POL_EFF_DT]
  
  # FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
  vio_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=DRVR_STRT_DT]
  
  # DELETE OLDER THAN 35 MONTH VIOLATION DATE
  vio_data <- vio_data[!((DRVR_INCID_DT > as.Date('1911-11-11')) & (DRVR_STRT_DT - DRVR_INCID_DT + 1 >= 1095))]
  
  # DELETE VIOLATION DATE > START DATE
  vio_data <- vio_data[!(DRVR_INCID_DT > DRVR_STRT_DT)]
  
  # COUNT P SOURCE AAF
  vio_data[, DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]
  vio_data[, P_SRCE_AAF:=ifelse(VIOL_CD=='AAF' & DRVR_PNT_SRCE_CD=='P', 1, 0)]
  vio_data <- vio_data[, .(P_SRCE_AAF=sum(P_SRCE_AAF)), by=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN CLAIM HISTORY TO BASE DATA
  base_data <- clm_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  base_data[is.na(AAF_3YR), AAF_3YR:=0]
  
  # JOIN VIOLATIONS TO BASE DATE
  base_data <- vio_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  base_data[is.na(P_SRCE_AAF), P_SRCE_AAF:=0]
  
  # SUBTRACT P SOURCE AAF FROM 3 YR COUNT
  base_data[, AAF_3YR:=pmax(AAF_3YR-P_SRCE_AAF,0)]
  
  # GROUP PLA COUNT
  base_data[, PLA_CNT_GRP:=as.character(AAF_3YR)]
  base_data[! PLA_CNT_GRP %in% c('0', '1', '2'), PLA_CNT_GRP:='3+']
  base_data[RENW_SFX_NBR==0, PLA_CNT_GRP:='N']
  
  # FORMATTING
  base_data[, PLA_CNT_GRP:=as.factor(PLA_CNT_GRP)]
  
  # DROP COLUMNS
  base_data[, AAF_3YR:=NULL]
  base_data[, P_SRCE_AAF:=NULL]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
