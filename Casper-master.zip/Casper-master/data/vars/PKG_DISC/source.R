library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PKG_DISC'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('SIC_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # GET COMMERCIAL COVERAGE CODE AND BUSINESS USE FROM CAW
  caw_qry <- "
    SELECT DISTINCT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.CMRCL_COV_CD,
      CAW.POLICY.BSNS_USE_CD
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
  ;
  "
  # INSERT DATES INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # JOIN CAW DATA TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # DETERMINE PACKAGE DISC
  na_sics <- c('4210','4214','4953','4954','4955','4211','4212','4213','4216','4217','4218','4219',
               '4220','4222','4229','7546','9097','2410','5093','5270')
  base_data[, PKG_DISC:='U']
  base_data[CMRCL_COV_CD %in% c('G', 'B', 'P', 'L'), PKG_DISC:='Y']
  base_data[CMRCL_COV_CD %in% c('N', 'M'), PKG_DISC:='N']
  base_data[SIC_CD %in% na_sics, PKG_DISC:='N/A']
  base_data[PKG_DISC!='N/A' & BSNS_USE_CD=='A', PKG_DISC:='U']
  base_data[, PKG_DISC:=as.factor(PKG_DISC)]
  
  # DROP COLUMNS
  base_data[, CMRCL_COV_CD:=NULL]
  base_data[, BSNS_USE_CD:=NULL]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
