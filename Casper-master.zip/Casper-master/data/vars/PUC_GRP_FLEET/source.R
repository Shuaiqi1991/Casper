library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PUC_GRP_FLEET'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('POWER_UNIT_CNT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[, PUC_GRP_FLEET:='1']
  base_data[POWER_UNIT_CNT==2, PUC_GRP_FLEET:='2']
  base_data[POWER_UNIT_CNT==3, PUC_GRP_FLEET:='3']
  base_data[POWER_UNIT_CNT==4, PUC_GRP_FLEET:='4']
  base_data[POWER_UNIT_CNT %in% c(5, 6), PUC_GRP_FLEET:='5-6']
  base_data[POWER_UNIT_CNT %in% c(7, 8, 9), PUC_GRP_FLEET:='7-9']
  base_data[POWER_UNIT_CNT>=10, PUC_GRP_FLEET:='10+']
  
  # FORMATTING
  base_data[, PUC_GRP_FLEET:=as.factor(PUC_GRP_FLEET)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
