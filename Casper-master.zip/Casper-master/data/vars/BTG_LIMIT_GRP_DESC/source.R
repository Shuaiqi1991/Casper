library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BTG_LIMIT_GRP_DESC'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BTG_LIMIT', 'LIMIT_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE
  base_data[, BTG_LIMIT_GRP_DESC:=paste0(BTG_LIMIT, '_', LIMIT_GRP_DESC)]
  
  # FORMATTING
  base_data[, BTG_LIMIT_GRP_DESC:=as.factor(BTG_LIMIT_GRP_DESC)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
