library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'FCC_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  fcc_qry <- 
  "
    SELECT
      CAW.VEHICLE.ST_CD, 
    	CAW.VEHICLE.PHYS_POL_KEY,
      CAW.VEHICLE.PHYS_VEH_KEY,
    	CAW.VEHICLE.FULL_COV_CD  
    FROM
      CAW.POL_DATES,
    	CAW.VEHICLE 
    WHERE 
    	CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
    	AND CAW.POL_DATES.POL_ID_CHAR = CAW.VEHICLE.POL_ID_CHAR 
    	AND CAW.POL_DATES.RENW_SFX_NBR = CAW.VEHICLE.RENW_SFX_NBR 
    	AND CAW.POL_DATES.POL_EXPR_YR = CAW.VEHICLE.POL_EXPR_YR 
    GROUP BY
      CAW.VEHICLE.ST_CD, 
    	CAW.VEHICLE.PHYS_POL_KEY,
      CAW.VEHICLE.PHYS_VEH_KEY,
      CAW.VEHICLE.FULL_COV_CD
    ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  fcc_qry <- str_replace_all(fcc_qry, 'startdate', start_date)
  fcc_qry <- str_replace_all(fcc_qry, 'enddate', end_date)
  
  # RUN QUERIES
  fcc_data <- as.data.table(dbGetQuery(caw_con, fcc_qry))
  
  # READ LOOKUP TABLES
  lookup_fcc <- fread(here(var_lib_path, 'FCC_GRP', 'lookup_fcc.csv'))
  
  # DELETE EXISTING VARIABLE, IF IT EXISTS
  if ('FULL_COV_CD' %in% names(base_data)) base_data[, FULL_COV_CD:=NULL]
  if ('FCC_GRP' %in% names(base_data)) base_data[, FCC_GRP:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- fcc_data[base_data, on =.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # FORMATTING
  base_data[, FULL_COV_CD:=trimws(FULL_COV_CD)]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- lookup_fcc[base_data, on=.(FULL_COV_CD)]
  
  # NAs
  base_data[is.na(FCC_GRP), FCC_GRP:='FullCov']
  
  # FORMATING
  base_data[, FCC_GRP:=as.factor(FCC_GRP)]
  
  # DROP UNNECESSARY COLUMN
  base_data[, FULL_COV_CD:=NULL]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
