library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'VEH_AGE_RAW'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN POLICIES
  caw_qry <- 
  "
    SELECT 
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEH_DATES.VEH_STRT_DT,
      CAW.VEHICLE.VEH_MODL_YR,
      CAW.BODYTYP.TRLR_OR_POWER
    FROM 
      CAW.VEHICLE, 
      CAW.VEH_DATES,
      CAW.POL_DATES, 
      CAW.POLICY,
      CAW.BODYTYP,
      CAW.BUSTYP
    WHERE 
      CAW.VEHICLE.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.VEHICLE.POL_ID_CHAR = CAW.VEH_DATES.POL_ID_CHAR 
	    AND CAW.VEHICLE.RENW_SFX_NBR = CAW.VEH_DATES.RENW_SFX_NBR 
	    AND CAW.VEHICLE.POL_EXPR_YR = CAW.VEH_DATES.POL_EXPR_YR 
	    AND CAW.VEHICLE.VEH_POS_CNT = CAW.VEH_DATES.VEH_POS_CNT 
	    AND CAW.VEHICLE.VEH_VRSN_NBR = CAW.VEH_DATES.VEH_VRSN_NBR 
      AND CAW.VEHICLE.VEH_BODY_TYP = CAW.BODYTYP.VEH_BODY_TYP 
	    AND CAW.POLICY.SIC_CD = CAW.BUSTYP.CV_INDSTR_CLSS_CD 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEH_DATES.VEH_STRT_DT,
      CAW.VEHICLE.VEH_MODL_YR,
      CAW.BODYTYP.TRLR_OR_POWER
      ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERIES
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # FORMATTING
  caw_data[, VEH_MODL_YR:=as.integer(VEH_MODL_YR)]
  
  # CALCULATE VEHICLE AGE
  data_year <- lubridate::year(as.Date(end_date)) + 1 - 2000
  caw_data[!is.na(VEH_MODL_YR), MDL_YR:=ifelse(VEH_MODL_YR<=data_year, VEH_MODL_YR+2000, VEH_MODL_YR+1900)]
  caw_data[!is.na(VEH_MODL_YR), VEH_AGE_RAW:=lubridate::year(VEH_STRT_DT) - MDL_YR]
  
  # SET TRAILER AGES TO 1, NEGATIVE AGES TO 0, OVER 50 TO 50
  caw_data[TRLR_OR_POWER=='T', VEH_AGE_RAW:=1]
  caw_data[VEH_AGE_RAW<0, VEH_AGE_RAW:=0]
  caw_data[VEH_AGE_RAW>=50, VEH_AGE_RAW:=50]
  
  # DROP UNNECESSARY COLUMNS
  caw_data <- caw_data[, .(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY, VEH_AGE_RAW)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('VEH_AGE_RAW' %in% names(base_data)) base_data[, VEH_AGE_RAW:=NULL]
  
  # JOIN ONTO BASE DATASET
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # FORMATTING
  base_data[is.na(VEH_AGE_RAW), VEH_AGE_RAW:=0]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}
