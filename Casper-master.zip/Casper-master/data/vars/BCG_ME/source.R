library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BCG_ME'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('SIC_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_bcg <- fread(here(var_lib_path, 'BCG_ME', 'lookup_bcg.csv'))
  lookup_bcg[, SIC_CD:=str_pad(SIC_CD, width=4, side='left', pad='0')]
  lookup_bcg[, BCG_ME:=as.character(BCG_ME)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('BCG_ME' %in% names(base_data)) base_data[, BCG_ME:=NULL]
  
  # LOOKUP BCG ON BASE DATA
  base_data <- lookup_bcg[, .(SIC_CD, BCG_ME)][base_data, on=.(SIC_CD)]
  
  # FORMATTING
  base_data[is.na(BCG_ME), BCG_ME:='999']
  base_data[, BCG_ME:=trimws(BCG_ME)]
  base_data[, BCG_ME:=as.factor(BCG_ME)]
  base_data[, SIC_CD:=as.factor(SIC_CD)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
