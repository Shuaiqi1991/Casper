library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'VEH_PERS_USE_IND'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- 
  "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_PERS_USE_IND 
    FROM 
      CAW.POL_DATES, 
      CAW.VEHICLE, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POLICY.POL_ID_CHAR = CAW.VEHICLE.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.VEHICLE.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.VEHICLE.POL_EXPR_YR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_PERS_USE_IND
    ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERIES
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('VEH_PERS_USE_IND' %in% names(base_data)) base_data[, VEH_PERS_USE_IND:=NULL]
  
  # JOIN USE ONTO BASE DATASET
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # FORMATTING
  base_data[! VEH_PERS_USE_IND %in% c('N', 'Y'), VEH_PERS_USE_IND:='N']
  base_data[, VEH_PERS_USE_IND:=as.factor(VEH_PERS_USE_IND)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}
