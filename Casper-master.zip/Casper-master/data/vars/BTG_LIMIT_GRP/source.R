library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BTG_LIMIT_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BTG_LIMIT', 'LIMIT_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE
  base_data[, BTG_LIMIT_GRP:=paste0(BTG_LIMIT, '_', LIMIT_GRP)]
  
  # FORMATTING
  base_data[, BTG_LIMIT_GRP:=as.factor(BTG_LIMIT_GRP)]
 
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
