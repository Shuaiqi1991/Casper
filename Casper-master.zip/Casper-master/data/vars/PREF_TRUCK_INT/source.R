library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PREF_TRUCK_INT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('PREF_TRUCK', 'BMT_NO_LIV')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE
  base_data[, PREF_TRUCK_INT:=paste0(BMT_NO_LIV, '_', PREF_TRUCK)]
  base_data[PREF_TRUCK %in% c('BACON'), PREF_TRUCK_INT:='BACON']
  
  # FORMATTING
  base_data[, PREF_TRUCK_INT:=as.factor(PREF_TRUCK_INT)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
