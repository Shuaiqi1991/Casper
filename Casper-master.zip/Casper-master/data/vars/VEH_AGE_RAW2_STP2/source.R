library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'VEH_AGE_RAW2_STP2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_AGE_RAW2')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # DUPLICATE VARIABLE
  base_data[, VEH_AGE_RAW2_STP2:=VEH_AGE_RAW2]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
