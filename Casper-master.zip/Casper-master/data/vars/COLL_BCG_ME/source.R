library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'COLL_BCG_ME'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('SIC_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_bcg <- fread(here(var_lib_path, 'COLL_BCG_ME', 'lookup_bcg.csv'))
  lookup_bcg[, SIC_CD:=str_pad(SIC_CD, width=4, side='left', pad='0')]
  lookup_bcg[, BCG_ME:=as.character(BCG_ME)]
  setnames(lookup_bcg, 'BCG_ME', 'COLL_BCG_ME')
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('COLL_BCG_ME' %in% names(base_data)) base_data[, COLL_BCG_ME:=NULL]
  
  # LOOKUP BCG ON BASE DATA
  base_data <- lookup_bcg[, .(SIC_CD, COLL_BCG_ME)][base_data, on=.(SIC_CD)]
  
  # FORMATTING
  base_data[is.na(COLL_BCG_ME), BCG_ME:='999']
  base_data[, COLL_BCG_ME:=trimws(COLL_BCG_ME)]
  base_data[, COLL_BCG_ME:=as.factor(COLL_BCG_ME)]
  base_data[, SIC_CD:=as.factor(SIC_CD)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
