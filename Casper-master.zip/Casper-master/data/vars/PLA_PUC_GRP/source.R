library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PLA_PUC_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('POWER_UNIT_CNT', 'PLA_CNT_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # PUC GROUP COMPONENT
  base_data[, TEMP_PUC_GRP:=as.character(POWER_UNIT_CNT)]
  base_data[POWER_UNIT_CNT>=4, TEMP_PUC_GRP:='4+']
  base_data[! TEMP_PUC_GRP %in% c('2', '3', '4+'), TEMP_PUC_GRP:='1']
  
  # CONCATENATE
  base_data[, PLA_PUC_GRP:=paste0(PLA_CNT_GRP, '_', TEMP_PUC_GRP)]
  base_data[PLA_CNT_GRP=='N', PLA_PUC_GRP:='N']
  base_data[, PLA_PUC_GRP:=as.factor(PLA_PUC_GRP)]
  
  # DROP COLUMNS
  base_data[, TEMP_PUC_GRP:=NULL]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
