library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'EFT_CURR_TERM'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN EFT
  eft_qry <- "
    SELECT 
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.EFT_IND 
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.EFT_IND 
  ;
  "
  # INSERT SELECTED START AND END DATE INTO QUERY
  eft_qry <- str_replace_all(eft_qry, 'startdate', start_date)
  eft_qry <- str_replace_all(eft_qry, 'enddate', end_date)
  
  # RUN QUERIES
  eft_data <- as.data.table(dbGetQuery(caw_con, eft_qry))
  
  # RENMAE
  setnames(eft_data, old=c("EFT_IND"), new=c("EFT_CURR_TERM"))
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('EFT_CURR_TERM' %in% names(base_data)) base_data[, EFT_CURR_TERM:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- eft_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMAT
  base_data[,EFT_CURR_TERM:=trimws(EFT_CURR_TERM)]
  base_data[,EFT_CURR_TERM:=as.factor(EFT_CURR_TERM)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
