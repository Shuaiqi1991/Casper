library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BUS_TIER'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'CR_GRP', 'UW_ROW')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  # CREDIT COMPONENT
  base_data[, TEMP_CR_GRP:=substr(CR_GRP, 1, 1)]
  base_data[TEMP_CR_GRP %in% c('A', 'B'), TEMP_CR_GRP:='A/B']
  base_data[TEMP_CR_GRP %in% c('D', 'E'), TEMP_CR_GRP:='D/E']
  base_data[! TEMP_CR_GRP %in% c('A/B', 'C', 'D/E'), TEMP_CR_GRP:='X']
  
  # UW ROW COMPONENT
  base_data[, TEMP_UW_ROW:=UW_ROW]
  base_data[TEMP_UW_ROW %in% c('2', '3', '4'), TEMP_UW_ROW:='2/3/4']
  
  # CONCATENATED
  base_data[, BUS_TIER:=paste0(BMT_NO_LIV, '_', TEMP_CR_GRP, '_', TEMP_UW_ROW)]
  base_data[, BUS_TIER:=as.factor(BUS_TIER)]
  
  # DROP COLUMNS
  base_data[, TEMP_CR_GRP:=NULL]
  base_data[, TEMP_UW_ROW:=NULL]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
