library(data.table)
library(odbc)
library(lubridate)

# DEFINE VARIABLE
var_name <- 'CNC_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY FOR POLICIES
  caw_qry <- "
    SELECT DISTINCT
      CAW.POL_DATES.ST_CD
      ,CAW.POL_DATES.PHYS_POL_KEY
      ,CAW.POL_DATES.POL_EFF_DT
      ,CAW.POL_DATES.POL_STRT_DT
      ,CAW.POL_DATES.POL_ID_NBR
      ,DSE.STATE.ALPHA_ST_CD
    FROM
      CAW.POL_DATES,
      DSE.STATE
    WHERE
      CAW.POL_DATES.POL_STRT_DT >= {d 'start_date_minus_1yr'}
      AND CAW.POL_DATES.POL_STRT_DT <= {d 'end_date'}
      AND DSE.STATE.ST_CD = CAW.POL_DATES.ST_CD
    ORDER BY
      CAW.POL_DATES.POL_EFF_DT
  "
  
  # REPLACE DATES IN QUERY
  start_date_minus_1yr <- as.Date(start_date) %m+% years(-1)
  start_date_minus_1yr <- as.character(start_date_minus_1yr)
  caw_qry <- str_replace_all(caw_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  caw_qry <- str_replace_all(caw_qry, 'end_date', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # PBW QUERY
  pbw_qry <- "
    SELECT 
      PBW.ACCT_TRAN.BIL_ACY_DT
      ,PBW.ACCT_TRAN.POL_NBR
      ,PBW.ACCT_TRAN.POL_NBR_NUMERIC
      ,PBW.ACCT_TRAN.POL_SFX
      ,PBW.ACCT_TRAN.POL_EFFECTIVE_DT
      ,PBW.ACCT_TRAN.PROD_CD
      ,PBW.ACCT_TRAN.BIL_STATE_PVN_CD
    FROM
      PBW.ACCT_TRAN
    WHERE
      PBW.ACCT_TRAN.PROD_CD = 'CA'
      AND PBW.ACCT_TRAN.TRAN_TYP_CD = '   CNC'
      AND PBW.ACCT_TRAN.POL_EFFECTIVE_DT <= BIL_ACY_DT
      AND PBW.ACCT_TRAN.POL_EFFECTIVE_DT >= {d 'start_date_minus_1yr'}
      AND PBW.ACCT_TRAN.POL_EFFECTIVE_DT <= {d 'end_date'}
  "
  
  # REPLACE DATES IN QUERY
  pbw_qry <- str_replace_all(pbw_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  pbw_qry <- str_replace_all(pbw_qry, 'end_date', end_date)
  
  # RUN QUERY
  pbw_data <- as.data.table(dbGetQuery(caw_con, pbw_qry))
  
  # TRIM STATE FIELD
  pbw_data[, BIL_STATE_PVN_CD:=trimws(BIL_STATE_PVN_CD)]
  
  # JOIN CAW DATA TO PBW DATA
  pbw_data <- caw_data[pbw_data, on=.(POL_ID_NBR=POL_NBR_NUMERIC, 
                                      POL_EFF_DT=POL_EFFECTIVE_DT, 
                                      ALPHA_ST_CD=BIL_STATE_PVN_CD)]
  
  # CANCEL COUNTS AT POLICY LEVEL
  pbw_data <- pbw_data[, .(CNC_CNT=.N), by=.(ST_CD, PHYS_POL_KEY, POL_ID_NBR, POL_EFF_DT)]
  
  # GET RENEWAL COUNTS AND COHORT ID FROM CAW
  pol_qry <- "
    SELECT DISTINCT
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.COH_ID_NBR, 
      CAW.POLICY.RENW_CNT, 
      CAW.POLICY.POL_TERM 
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'start_date_minus_1yr'} and {d 'end_date'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
  ;
  "
  
  # REPLACE DATES IN QUERY
  pol_qry <- str_replace_all(pol_qry, 'start_date_minus_1yr', start_date_minus_1yr)
  pol_qry <- str_replace_all(pol_qry, 'end_date', end_date)

  # RUN QUERY
  pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  
  # JOIN CANCEL COUNTS TO POLICY TERM DATA
  pol_data <- pbw_data[pol_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # ORDER DATA BY POLICY, RENEWAL COUNT
  pol_data <- pol_data[order(ST_CD, POL_ID_NBR, COH_ID_NBR, RENW_CNT)]
  
  # GET PRIOR TERM CANCEL COUNTS AND POLICY TERM
  prior_data <- copy(pol_data)
  prior_data[, NEXT_RENW_CNT:=RENW_CNT+1]
  prior_data <- prior_data[, .(ST_CD, POL_ID_NBR, COH_ID_NBR, NEXT_RENW_CNT, CNC_CNT, POL_TERM)]
  setnames(prior_data, c('CNC_CNT', 'POL_TERM'), c('PRIOR_CNC', 'PRIOR_TERM'))
  pol_data <- prior_data[pol_data, on=.(ST_CD, POL_ID_NBR, COH_ID_NBR, NEXT_RENW_CNT=RENW_CNT)]
  
  # REDUCE COLUMNS
  pol_data <- pol_data[, .(ST_CD, PHYS_POL_KEY, PRIOR_CNC, PRIOR_TERM)]
  
  # JOIN TO BASE DATA
  base_data <- pol_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # MAP NAs TO 999
  base_data[, PRIOR_TERM:=as.integer(PRIOR_TERM)]
  base_data[is.na(PRIOR_CNC), PRIOR_CNC:=999]
  base_data[is.na(PRIOR_TERM), PRIOR_TERM:=999]
  base_data[PRIOR_TERM!=999 & PRIOR_CNC==999, PRIOR_CNC:=0]
  base_data[PRIOR_TERM==999, PRIOR_CNC:=999]
  
  # GROUPING
  base_data[, CNC_CALC:=ceiling(PRIOR_CNC * (12 / PRIOR_TERM))]
  base_data[, CNC_GRP:=as.character(CNC_CALC)]
  base_data[CNC_CALC>=5, CNC_GRP:='5+']
  base_data[PRIOR_TERM=='999'|PRIOR_CNC=='999', CNC_GRP:='U']
  
  # DROP COLUMNS
  drop_cols <- c('PRIOR_TERM', 'PRIOR_CNC', 'CNC_CALC')
  base_data[, c(drop_cols):=NULL]
  
  # FORMATTING
  base_data[, CNC_GRP:=as.factor(CNC_GRP)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
