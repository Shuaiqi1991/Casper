library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'COLL_BTG_VEH_AGE_GRP_2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('COLL_BTG_VEH_AGE_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # DUPLICATE FIELD
  base_data[, COLL_BTG_VEH_AGE_GRP_2:=COLL_BTG_VEH_AGE_GRP]
  
  # REMOVE GROUP 7
  base_data[COLL_BTG_VEH_AGE_GRP_2=='DumpsFHS', COLL_BTG_VEH_AGE_GRP_2:='Dumps']
  
  # FACTORIZE
  base_data[, COLL_BTG_VEH_AGE_GRP_2:=as.factor(COLL_BTG_VEH_AGE_GRP_2)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
