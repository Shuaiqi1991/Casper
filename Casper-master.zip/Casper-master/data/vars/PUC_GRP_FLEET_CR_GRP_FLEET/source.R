library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PUC_GRP_FLEET_CR_GRP_FLEET'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('PUC_GRP_FLEET', 'CR_GRP_FLEET')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[,PUC_GRP_FLEET_CR_GRP_FLEET:=paste0(PUC_GRP_FLEET,"_",CR_GRP_FLEET)]
  
  # FORMAT
  base_data[, PUC_GRP_FLEET_CR_GRP_FLEET:=as.factor(PUC_GRP_FLEET_CR_GRP_FLEET)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
