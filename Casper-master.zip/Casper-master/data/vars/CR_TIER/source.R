library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'CR_TIER'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('CR_SCR')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- 
  "
    SELECT
    	CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY, 
    	CAW.POLICY.CR_SCORE_CD 
    FROM 
    	CAW.POL_DATES, 
    	CAW.POLICY 
    WHERE 
    	CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
    	AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
    	AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
    	AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR
    GROUP BY
      CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY, 
    	CAW.POLICY.CR_SCORE_CD
  ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # CAW QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # READ IN LOOKUP TABLES
  lookup_tier <- fread(here(var_lib_path, 'CR_TIER', 'lookup_tier.csv'))
  lookup_st  <- fread(here(var_lib_path, 'CR_TIER', 'lookup_st_grp.csv'))
  lookup_st[, ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  
  # JOIN CREDIT STATE GROUP TO CAW DATA
  caw_data <- lookup_st[caw_data, on=.(ST_CD)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('CREDIT_ST_GRP' %in% names(base_data)) base_data[, CREDIT_ST_GRP:=NULL]
  if ('CR_SCORE_CD' %in% names(base_data)) base_data[, CR_SCORE_CD:=NULL]
  if ('CR_TIER' %in% names(base_data)) base_data[, CR_TIER:=NULL]
  
  # JOIN CAW DATA TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN CREDIT TIER TO BASE DATA
  base_data <- lookup_tier[base_data, on=.(CREDIT_ST_GRP, CR_SCR), roll=T]
  
  # FORMATTING
  base_data[CR_TIER=='', CR_TIER:=CR_SCORE_CD]
  base_data[is.na(CR_TIER), CR_TIER:=CR_SCORE_CD]
  base_data[, CR_TIER:=trimws(CR_TIER)]
  base_data[CR_TIER=='', CR_TIER:='XX']
  base_data[CR_TIER=='NA', CR_TIER:='XX']
  base_data[is.na(CR_TIER), CR_TIER:='XX']
  base_data[, CR_TIER:=as.factor(CR_TIER)]
  
  # REMOVE UNNECESSARY COLUMNS
  base_data[, CREDIT_ST_GRP:=NULL]
  base_data[, CR_SCORE_CD:=NULL]
 
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
