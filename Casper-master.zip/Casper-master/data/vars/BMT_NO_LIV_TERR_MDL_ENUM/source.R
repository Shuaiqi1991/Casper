library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BMT_NO_LIV_TERR_MDL_ENUM'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'TERR_MDL_ENUM')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE BMT_NO_LIV AND TERR_MDL_ENUM
  base_data[, BMT_NO_LIV_TERR_MDL_ENUM:=paste0(BMT_NO_LIV, '_', TERR_MDL_ENUM)]
  base_data[, BMT_NO_LIV_TERR_MDL_ENUM:=as.factor(BMT_NO_LIV_TERR_MDL_ENUM)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
