library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'VEH_MOCK_IND'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- "
    SELECT DISTINCT
    	CAW.VEHICLE.ST_CD, 
      CAW.VEHICLE.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_MOCK_IND 
    FROM 
      CAW.POL_DATES, 
      CAW.VEHICLE 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.VEHICLE.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
  ;
  "
  
  # INSERT DATES INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # FORMATTING
  base_data[VEH_MOCK_IND!='Y', VEH_MOCK_IND:='N']
  base_data[, VEH_MOCK_IND:=as.factor(VEH_MOCK_IND)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
