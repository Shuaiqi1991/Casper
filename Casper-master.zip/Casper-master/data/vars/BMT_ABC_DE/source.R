library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BMT_ABC_DE'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  truck_bmts <- c('A-For Hire Spec', 'B-For Hire Trans', 'C-Tow')
  base_data[, BMT_ABC_DE:=ifelse(BMT_NO_LIV %in% truck_bmts, 'ABC', 'DE')]
  base_data[, BMT_ABC_DE:=as.factor(BMT_ABC_DE)]
 
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
