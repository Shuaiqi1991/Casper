library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'AGE_AND_PTS'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # VIOLATIONS QUERY
  viol_qry <- 
  "
    SELECT 
    	CAW.DRIVER_VIOL.ST_CD, 
      CAW.DRIVER_VIOL.PHYS_POL_KEY, 
      CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
      CAW.DRIVER_VIOL.VIOL_CD, 
      CAW.DRIVER_VIOL.DRVR_INCID_DT, 
      CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
    FROM 
      CAW.DRIVER_VIOL
    WHERE 
      CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
    ;
  "
  
  # DRIVER DATES QUERY
  dts_qry <- 
  "
    SELECT 
    	CAW.DRVR_DATES.ST_CD, 
    	CAW.DRVR_DATES.PHYS_POL_KEY, 
      CAW.DRVR_DATES.PHYS_DRVR_KEY,
    	CAW.DRVR_DATES.DRVR_POS_CNT, 
    	CAW.DRVR_DATES.DRVR_STRT_DT 
    FROM 
    	CAW.DRVR_DATES
    WHERE
      CAW.DRVR_DATES.DRVR_STRT_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    ;
  "
  
  # POLICY DATES QUERY
  pol_qry <- 
  "
    SELECT 
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POL_DATES.POL_EFF_DT 
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    ;
  "
  
  # INSERT START AND END DATE INTO QUERY
  min_pol_expr_yr <- lubridate::year(as.Date(start_date))
  pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(today())+1)
  pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
  pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
  viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
  dts_qry <- str_replace_all(dts_qry, 'startdate', start_date)
  dts_qry <- str_replace_all(dts_qry, 'enddate', end_date)
  pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
  pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)
  
  # GET VIOLATION DATA
  viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))
  
  # GET DRIVER DATES DATA
  dts_data <- as.data.table(dbGetQuery(caw_con, dts_qry))
  
  # GET POLICY DATES
  pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  
  # GET FIRST DRIVER DATE
  dts_data <- dts_data[order(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT, DRVR_STRT_DT)]
  first_inds <- dts_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
  dts_data <- dts_data[first_inds]
  
  # JOIN VIOLATION AND DATES DATA
  viol_data <- dts_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # JOIN DATES AND VIOLATION DATA
  viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))
  
  # NA DRIVER START DATES ARE ASSIGNED TO POLICY EFFECTIVE DATE
  viol_data[is.na(DRVR_STRT_DT), DRVR_STRT_DT:=POL_EFF_DT]
  
  # FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
  viol_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=DRVR_STRT_DT]
  
  # DELETE OLDER THAN 35 MONTH VIOLATION DATE
  viol_data <- viol_data[!((DRVR_INCID_DT > as.Date('1911-11-11')) & (DRVR_STRT_DT - DRVR_INCID_DT + 1 >= 1095))]
  
  # DELETE VIOLATION DATE > START DATE
  viol_data <- viol_data[!(DRVR_INCID_DT > DRVR_STRT_DT)]
  
  # LOOKUP VIOLATION CLASS
  lookup_vio_cls <- fread(here(var_lib_path, 'AGE_AND_PTS', 'lookup_vio_cls.csv'))
  viol_data[, VIOL_CD:=trimws(VIOL_CD)]
  viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
  # IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
  viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']
  
  # ASSIGN POINTS FOR FIRST VIOLATION
  viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
  first_viol_pts <- fread(here(var_lib_path, 'AGE_AND_PTS', 'lookup_first_pts.csv'))
  viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

  # ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
  addtl_viol_pts <- fread(here(var_lib_path, 'AGE_AND_PTS', 'lookup_addtl_pts.csv'))
  setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
  viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
  first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
  viol_data[!first_inds, VIOL_PT:=ADDTL_PT]
  
  # REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
  viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
  first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
  viol_data <- viol_data[first_inds]
  
  # REASSIGN POINTS AFTER SAME DAY FILTER
  viol_data[, VIOL_PT:=NULL]
  viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
  viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]
  viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
  first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
  viol_data[!first_inds, VIOL_PT:=ADDTL_PT]
  
  # SUMMARIZE POINT SUM TO DRIVER LEVEL
  viol_data <- viol_data[, .(DRVR_PTS=sum(VIOL_PT)), by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

  # CAW QUERY
  drv_qry <- 
  "
    SELECT 
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
      CAW.DRVR_PUB_VIEW.DRVR_POS_CNT,
      CAW.DRVR_DATES.DRVR_AT_INCP_IND, 
      CAW.POLICY.POWER_UNIT_CNT,
      CAW.DRVR_PUB_VIEW.DRVR_AGE, 
      CAW.DRVR_PUB_VIEW.EXCL_IND, 
      CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
    FROM 
      CAW.POL_DATES, 
      CAW.DRVR_DATES, 
      CAW.DRVR_PUB_VIEW, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POLICY.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
      AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
      AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
      AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
      AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
      AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
      AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
      CAW.DRVR_PUB_VIEW.DRVR_POS_CNT,
      CAW.DRVR_DATES.DRVR_AT_INCP_IND, 
      CAW.POLICY.POWER_UNIT_CNT,
      CAW.DRVR_PUB_VIEW.DRVR_AGE, 
      CAW.DRVR_PUB_VIEW.EXCL_IND, 
      CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
  ;
  "
  
  # INSERT START AND END DATE INTO QUERY
  drv_qry <- str_replace_all(drv_qry, 'startdate', start_date)
  drv_qry <- str_replace_all(drv_qry, 'enddate', end_date)
  
  # GET DRIVER DATA
  drv_data <- as.data.table(dbGetQuery(caw_con, drv_qry))
  
  # JOIN POINTS TO DRIVER DATA
  drv_data <- viol_data[drv_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  drv_data[is.na(DRVR_PTS), DRVR_PTS:=0]
  
  # FILTER OUT MOCK DRIVERS, EXCLUDED DRIVERS, AND POST-INCEPTION DRIVERS
  drv_data <- drv_data[DRVR_AT_INCP_IND=='Y']
  drv_data <- drv_data[EXCL_IND!='Y']
  drv_data <- drv_data[DRVR_MOCK_IND!='Y']
  
  # GET FIRST RECORD FOR EACH DRIVER
  inds <- drv_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
  drv_data <- drv_data[inds, .(ST_CD, PHYS_POL_KEY, POWER_UNIT_CNT, DRVR_POS_CNT, DRVR_AGE, DRVR_PTS)]
  
  # AGE GROUPINGS
  lookup_age <- fread(here(var_lib_path, 'AGE_AND_PTS', 'lookup_age.csv'))
  lookup_age[, AGE_GRP:=str_pad(AGE_GRP, width=2, side='left', pad='0')]
  
  # LOOKUP AGE GROUP
  drv_data <- lookup_age[drv_data, on=.(DRVR_AGE), roll=T]
  
  # POINTS GROUPINGS
  drv_data[, PTS_GRP:=ifelse(DRVR_PTS>11, 11, DRVR_PTS)]
  drv_data[, PTS_GRP:=str_pad(PTS_GRP, width=2, side='left', pad='0')]
  drv_data[, PTS_GRP:=paste0('PTS_GRP_', PTS_GRP)]
  
  # AGE AND POINTS GROUPINGS
  drv_data[, AGE_PTS_GRP:='AGE_PTS_GRP_00']
  drv_data[DRVR_AGE %between% c(0, 29) & DRVR_PTS==0, AGE_PTS_GRP:='AGE_PTS_GRP_01']
  drv_data[DRVR_AGE %between% c(0, 29) & DRVR_PTS>0, AGE_PTS_GRP:='AGE_PTS_GRP_02']
  drv_data[DRVR_AGE %between% c(30, 59) & DRVR_PTS==0, AGE_PTS_GRP:='AGE_PTS_GRP_03']
  drv_data[DRVR_AGE %between% c(30, 59) & DRVR_PTS>0, AGE_PTS_GRP:='AGE_PTS_GRP_04']
  drv_data[DRVR_AGE %between% c(60, 75) & DRVR_PTS==0, AGE_PTS_GRP:='AGE_PTS_GRP_05']
  drv_data[DRVR_AGE %between% c(60, 75) & DRVR_PTS>0, AGE_PTS_GRP:='AGE_PTS_GRP_06']
  drv_data[DRVR_AGE %between% c(76, 99) & DRVR_PTS==0, AGE_PTS_GRP:='AGE_PTS_GRP_07']
  drv_data[DRVR_AGE %between% c(76, 99) & DRVR_PTS>0, AGE_PTS_GRP:='AGE_PTS_GRP_08']
  
  # CALCULATE NUMBER OF DRIVERS (DENOMINATOR)
  drv_data[, DRVR_CNT:=.N, by=.(ST_CD, PHYS_POL_KEY)]
  
  # CALCULATE NUMBER OF UNLISTED DRIVERS
  drv_data[, UNLD_CNT:=ifelse(POWER_UNIT_CNT>0 & POWER_UNIT_CNT>DRVR_CNT, POWER_UNIT_CNT-DRVR_CNT, 0)]
  
  # CALCULATE UNLISTED DRIVER PERCENTAGE
  uld_data <- unique(drv_data[, .(ST_CD, PHYS_POL_KEY, UNLD_CNT, DRVR_CNT)])
  uld_data[, UNLD_PCT:=UNLD_CNT/(UNLD_CNT+DRVR_CNT)]
  uld_data <- uld_data[, .(ST_CD, PHYS_POL_KEY, UNLD_PCT)]
  
  # CALCULATE DRIVER PERCENTAGE
  drv_data[, DRVR_PCT:=1/(DRVR_CNT+UNLD_CNT)]
  
  # SUM DRIVER PERCENTAGE IN EACH AGE GROUP, PTS GROUP, AGE & PTS GROUP
  age_data <- dcast(drv_data, ST_CD + PHYS_POL_KEY ~ AGE_GRP, fun.aggregate=sum, value.var='DRVR_PCT')
  pts_data <- dcast(drv_data, ST_CD + PHYS_POL_KEY ~ PTS_GRP, fun.aggregate=sum, value.var='DRVR_PCT')
  age_pts_data <- dcast(drv_data, ST_CD + PHYS_POL_KEY ~ AGE_PTS_GRP, fun.aggregate=sum, value.var='DRVR_PCT')
  
  # MERGE AGE GROUPS, PTS GROUPS, AND AGE & PTS GROUPS INTO ONE DATASET
  age_pts_data <- age_data[age_pts_data, on=.(ST_CD, PHYS_POL_KEY)]
  age_pts_data <- pts_data[age_pts_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # JOIN UNLISTED DRIVER PERCENTAGE
  age_pts_data <- uld_data[age_pts_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # DELETE EXISTING COLUMNS
  new_cols <- setdiff(names(age_pts_data), c('ST_CD', 'PHYS_POL_KEY'))
  for (col in new_cols) if (col %in% names(base_data)) base_data[, c(col):=NULL]
  
  # JOIN AGE AND POINTS TO BASE DATA
  base_data <- age_pts_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMAT NAs AS PTS_GRP_00
  base_data[, NA_SUM:=0]
  for (col in new_cols) base_data[, NA_SUM:=NA_SUM+get(col)] # BECOMES NA IF ANY ARE NA
  for (col in new_cols) base_data[is.na(NA_SUM), c(col):=0]
  base_data[is.na(NA_SUM), UNLD_PCT:=1]
  base_data[, NA_SUM:=NULL]
  
  # NAME COLUMN
  name_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY, 
      CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY,
      CAW.DRVR_PUB_VIEW.DRVR_AGE,
    	CAW.DRVR_PUB_VIEW.DRVR_PTS
    FROM 
    	CAW.DRVR_PUB_VIEW, 
    	CAW.POL_DATES, 
    	CAW.POLICY 
    WHERE 
			CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
    	AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
    	AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
    	AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    	AND CAW.POLICY.PHYS_POL_KEY = CAW.DRVR_PUB_VIEW.PHYS_POL_KEY 
    	AND CAW.POLICY.ST_CD = CAW.DRVR_PUB_VIEW.ST_CD
      AND CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND = 'N'
    GROUP BY
      CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY, 
      CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY,
      CAW.DRVR_PUB_VIEW.DRVR_AGE,
    	CAW.DRVR_PUB_VIEW.DRVR_PTS 
  ;
  "
  # INSERT START AND END DATE INTO QUERY
  name_qry <- str_replace_all(name_qry, 'startdate', start_date)
  name_qry <- str_replace_all(name_qry, 'enddate', end_date)
  name_data <- as.data.table(dbGetQuery(caw_con, name_qry))
  
  # DELETE EXISTING COLUMNS, IF ANY
  drop_cols <- c('DRVR_AGE', 'DRVR_PTS', 'AGE_GRP_NAME', 'PTS_GRP_NAME', 'AGE_PTS_NAME')
  for (col in drop_cols) if (col %in% names(base_data)) base_data[, c(col):=NULL]
  
  # JOIN
  base_data <- name_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # CREATE AGE PTS GRP NAME FIELD
  base_data[, AGE_PTS_NAME:='AGE_PTS_GRP_XX']
  base_data[DRVR_AGE %between% c(0, 29) & DRVR_PTS==0, AGE_PTS_NAME:='AGE_PTS_GRP_01']
  base_data[DRVR_AGE %between% c(0, 29) & DRVR_PTS>0, AGE_PTS_NAME:='AGE_PTS_GRP_02']
  base_data[DRVR_AGE %between% c(30, 59) & DRVR_PTS==0, AGE_PTS_NAME:='AGE_PTS_GRP_03']
  base_data[DRVR_AGE %between% c(30, 59) & DRVR_PTS>0, AGE_PTS_NAME:='AGE_PTS_GRP_04']
  base_data[DRVR_AGE %between% c(60, 75) & DRVR_PTS==0, AGE_PTS_NAME:='AGE_PTS_GRP_05']
  base_data[DRVR_AGE %between% c(60, 75) & DRVR_PTS>0, AGE_PTS_NAME:='AGE_PTS_GRP_06']
  base_data[DRVR_AGE %between% c(76, 99) & DRVR_PTS==0, AGE_PTS_NAME:='AGE_PTS_GRP_07']
  base_data[DRVR_AGE %between% c(76, 99) & DRVR_PTS>0, AGE_PTS_NAME:='AGE_PTS_GRP_08']
  base_data[is.na(AGE_PTS_NAME) | DRVR_MOCK_IND=='Y', AGE_PTS_NAME:='AGE_PTS_GRP_XX']
  base_data[, AGE_PTS_GRP_XX:=0]
  base_data[, AGE_PTS_NAME:=as.factor(AGE_PTS_NAME)]
  
  # CREATE PTS GRP NAME FIELD
  base_data[, PTS_GRP_NAME:=DRVR_PTS]
  # CAP POINTS AT 11
  base_data[PTS_GRP_NAME>11, PTS_GRP_NAME:=11]
  # FORMATTING
  base_data[, PTS_GRP_NAME:=str_pad(PTS_GRP_NAME, width=2, side='left', pad='0')]
  base_data[, PTS_GRP_NAME:=paste0('PTS_GRP_', PTS_GRP_NAME)]
  # NAs AND MOCK DRIVERS GET SEPERATE GROUP
  base_data[is.na(PTS_GRP_NAME) | is.na(DRVR_PTS) | DRVR_MOCK_IND=='Y', PTS_GRP_NAME:='PTS_GRP_XX']
  base_data[, PTS_GRP_XX:=0]
  # FACTORIZE
  base_data[, PTS_GRP_NAME:=as.factor(PTS_GRP_NAME)]
  
  # CREATE AGE GRP NAME FIELD
  # LOOKUP AGE GROUP
  base_data <- lookup_age[base_data, on=.(DRVR_AGE), roll=T]
  # RENAME COLUMN JOINED FROM LOOKUP TABLE
  setnames(base_data, 'AGE_GRP', 'AGE_GRP_NAME')
  # NAs AND MOCK DRIVERS GET SEPERATE GROUP
  base_data[is.na(AGE_GRP_NAME) | is.na(DRVR_AGE) | DRVR_MOCK_IND=='Y', AGE_GRP_NAME:='AGE_GRP_XX']
  base_data[, AGE_GRP_XX:=0]
  # FACTORIZE
  base_data[, AGE_GRP_NAME:=as.factor(AGE_GRP_NAME)]
  
  # DROP UNLD_PCT = 1
  base_data <- base_data[UNLD_PCT!=1]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
