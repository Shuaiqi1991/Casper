library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'OOS_BMT_NO_LIV'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('OOS_DRVR_POL_LVL', 'BMT_NO_LIV')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE
  base_data[, OOS_BMT_NO_LIV:=paste0(OOS_DRVR_POL_LVL, '_', BMT_NO_LIV)]
  
  # FORMAT
  base_data[, OOS_BMT_NO_LIV:=as.factor(OOS_BMT_NO_LIV)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
