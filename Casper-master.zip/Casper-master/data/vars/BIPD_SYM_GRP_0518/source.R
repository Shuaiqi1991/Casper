library(data.table)
library(odbc)
library(lubridate)

# DEFINE VARIABLE
var_name <- 'BIPD_SYM_GRP_0518'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO VIW
  viw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # GET AUDIT DATE FROM END DATE (FIRST OF THE MONTH)
  audit_date <- as.Date(end_date)
  lubridate::day(audit_date) <- 1
  audit_date <- as.character(audit_date)
  
  # VIW QUERY
  viw_qry <- 
  "
    SELECT
      VIN_PFX
      ,MDL_YR
      ,LIAB_SYM
      ,COMP_SYM
      ,COLL_SYM
    FROM
      VIW.VIS_SYMBOL
    WHERE
      AUDIT_DT = {d 'auditdate'}
      AND FILE_DATE = '20080101'
  ;"
  
  # INSERT AUDIT DATE INTO QUERY
  viw_qry <- str_replace_all(viw_qry, 'auditdate', audit_date)
  
  # GET VIW DATA
  viw_data <- as.data.table(dbGetQuery(viw_con, viw_qry))
  
  # FORMAT YY MODEL YEAR AS YYYY
  viw_data[, MDL_YR_SYM:=2000+MDL_YR]
  viw_data[MDL_YR>=20, MDL_YR_SYM:=1900+MDL_YR]
  viw_data[, MDL_YR_SYM:=as.character(MDL_YR_SYM)]
  
  # LOWER AND UPPER BOUND
  viw_data[MDL_YR %between% c(81,89), MDL_YR_SYM:='1981 ... 1989']
  viw_data[MDL_YR %between% c(19,33), MDL_YR_SYM:='2019 ... 2033']
  
  # RENAME COLUMNS
  setnames(viw_data, 
           c('LIAB_SYM', 'COMP_SYM', 'COLL_SYM'), 
           c('SYMBOL_MAKE', 'SYMBOL_MODEL', 'SYMBOL_STYLE'))
  
  # READ IN MAPPING FILE
  lookup_sym <- fread(here(var_lib_path, 'BIPD_SYM_GRP_0518', 'lookup_sym.csv'))
  
  # RENAME COLUMNS
  setnames(lookup_sym,
           c('MDL-YR-FOR-SYM', 'SYMBOL-MAKE', 'SYMBOL-MODEL', 'SYMBOL-STYLE', 'BIPD Group'),
           c('MDL_YR_SYM', 'SYMBOL_MAKE', 'SYMBOL_MODEL', 'SYMBOL_STYLE', 'BIPD_GROUP'))
  lookup_sym <- lookup_sym[, .(MDL_YR_SYM, SYMBOL_MAKE, SYMBOL_MODEL, SYMBOL_STYLE, BIPD_GROUP)]
  
  # LOOKUP BIPD GROUP ON VIW DATA
  viw_data <- lookup_sym[viw_data, on=.(MDL_YR_SYM, SYMBOL_MAKE, SYMBOL_MODEL, SYMBOL_STYLE)]
  
  # VIN QUERY
  vin_qry <- 
  "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VIN
    FROM 
      CAW.VEHICLE, 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.VEHICLE.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VIN
  ;"
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  vin_qry <- str_replace_all(vin_qry, 'startdate', start_date)
  vin_qry <- str_replace_all(vin_qry, 'enddate', end_date)
  
  # GET VIN DATA
  vin_data <- as.data.table(dbGetQuery(viw_con, vin_qry))
  
  # JOIN VIN DATA AND SYMBOL DATA
  vin_data[, VIN_PFX_8:=substr(VIN, 1, 8)]
  vin_data[, VIN_PFX_10:=substr(VIN, 10, 10)]
  viw_data[, VIN_PFX_8:=substr(VIN_PFX, 1, 8)]
  viw_data[, VIN_PFX_10:=substr(VIN_PFX, 10, 10)]
  vin_data <- viw_data[vin_data, on=.(VIN_PFX_8, VIN_PFX_10)]
  
  # REMOVE UNNECESSARY COLUMNS
  vin_data <- vin_data[, .(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY, BIPD_GROUP)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('BIPD_SYM_GRP' %in% names(base_data)) base_data[, BIPD_SYM_GRP:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- vin_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # EXCLUDE CERTAIN BODY TYPES FROM SYMBOLING
  bts <- c('05','06','09','27','29','30','32','55','5A','5B','91')
  base_data[, BIPD_SYM_GRP:='0']
  base_data[VEH_BODY_TYP %in% bts, BIPD_SYM_GRP:=as.character(BIPD_GROUP)]
  base_data[is.na(BIPD_GROUP), BIPD_SYM_GRP:='0']
  
  # FIX SYMBOL GROUP FOR CERTAIN BODY TYPES
  base_data[VEH_BODY_TYP=='91', BIPD_SYM_GRP:='5']
  base_data[VEH_BODY_TYP %in% c('33', '35', '46'), BIPD_SYM_GRP:='0']
  
  # FORMATTING
  base_data[, BIPD_SYM_GRP:=as.factor(BIPD_SYM_GRP)]
  base_data[, BIPD_GROUP:=NULL]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
