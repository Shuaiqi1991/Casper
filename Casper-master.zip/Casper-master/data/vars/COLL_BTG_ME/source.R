library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'COLL_BTG_ME'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ IN LOOKUP TABLE
  lookup_bt_coll <- fread(here(var_lib_path, 'COLL_BTG_ME', 'lookup_bt_coll.csv'))

  # FORMATTING
  lookup_bt_coll[, VEH_BODY_TYP:=str_pad(VEH_BODY_TYP, width=2, side='left', pad='0')]
  lookup_bt_coll[, COLL_BTG_ME:=as.character(COLL_BTG_ME)]
    
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('COLL_BTG_ME' %in% names(base_data)) base_data[, COLL_BTG_ME:=NULL]

  # JOIN COLL_BTG_ME ONTO BASE DATASET
  base_data <- lookup_bt_coll[base_data, on=.(VEH_BODY_TYP)]
  
  # MAP NAs
  base_data[is.na(COLL_BTG_ME), COLL_BTG_ME:='999']
  
  # FORMATTING
  base_data[, COLL_BTG_ME:=as.factor(COLL_BTG_ME)]
  base_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
