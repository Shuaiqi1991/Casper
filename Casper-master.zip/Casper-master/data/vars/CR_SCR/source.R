library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'CR_SCR'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # GET CREDIT DATA
  cred_data <- fread(here(var_lib_path, 'CR_SCR', 'bin', 'd51_data.csv'),
                     colClasses=list(character=c('ST_CD', 'PHYS_POL_KEY')))
  
  # UNIFORMIZE CLASS
  cred_data[,ST_CD:=as.character(ST_CD)]
  cred_data[,PHYS_POL_KEY:=as.character(PHYS_POL_KEY)]
  cred_data[,POL_EFF_DT:=as.Date(POL_EFF_DT,"%d%b%Y")]
  if(class(base_data$POL_EFF_DT) != "Date") base_data[,POL_EFF_DT:=as.Date(POL_EFF_DT)]
  
  # KEEP THE MOST RECENT RECORD & REMOVE DUPLICATES
  cred_data <- cred_data[order(ST_CD, PHYS_POL_KEY, -POL_EFF_DT)]
  cred_data <- cred_data[, .(CR_SCR=D51_SCORE[1]), by=.(ST_CD, PHYS_POL_KEY, POL_EFF_DT)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('CR_SCR' %in% names(base_data)) base_data[, CR_SCR:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- cred_data[base_data, on=.(ST_CD, PHYS_POL_KEY, POL_EFF_DT)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
