library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'CR_SCR_2018'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- 
  "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.QT_KEY 
    FROM
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.QT_KEY 
  ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # GET CREDIT DATA
  cred_data <- fread(here(var_lib_path, 'CR_SCR_2018', 'bin', 'd51_data.csv'))
  
  # REMOVE DUPLICATES
  cred_data <- cred_data[order(-QTKEY)]
  cred_data <- cred_data[, .(CR_SCR_2018=D51SCR[1]), by=.(QT_KEY=QTKEY)]
  
  # JOIN CREDIT ONTO CAW DATASET
  caw_data <- cred_data[caw_data, on=.(QT_KEY)]
  caw_data[, QT_KEY:=NULL]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('CR_SCR_2018' %in% names(base_data)) base_data[, CR_SCR_2018:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
