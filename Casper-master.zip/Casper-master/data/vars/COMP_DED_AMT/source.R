library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'COMP_DED_AMT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # LOOKUP TABLES
  lookup_ded_amt <- fread(here(var_lib_path, 'COMP_DED_AMT', 'lookup_ded_amt.csv'))
  lookup_st_ded_amt <- fread(here(var_lib_path, 'COMP_DED_AMT', 'lookup_st_ded_amt.csv'))

  # FORMAT LOOKUPS
  lookup_ded_amt[, COMP_LCL:=as.character(COMP_LCL)]
  lookup_st_ded_amt[, COMP_LCL:=as.character(COMP_LCL)]
  lookup_st_ded_amt[, ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('COMP_DED_AMT' %in% names(base_data)) base_data[, COMP_DED_AMT:=NULL]
  
  # JOIN DED_AMT ONTO BASE DATASET
  base_data <- lookup_ded_amt[base_data, on=.(COMP_LCL)]
  base_data <- lookup_st_ded_amt[base_data, on=.(ST_CD, COMP_LCL)]
  base_data[!is.na(ST_COMP_DED_AMT), COMP_DED_AMT:=ST_COMP_DED_AMT]

  # DROP UNNECESSARY COLUMNS
  drop_cols <- c('ST_COMP_DED_AMT')
  base_data <- base_data[, -c(drop_cols), with=F]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
