library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BMT_V41_USDOT_LUSDOT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'V41_USDOT_SCR_GRPS')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[, BMT_V41_USDOT_LUSDOT:={
    lusdot <- ifelse(CALC_LUSDOT_YRS>=0, ifelse(CALC_LUSDOT_YRS>=3, '3+', '0-2'), 'NA')
    lusdot <- ifelse(V41_USDOT_SCR_GRPS %in% c('Z92', 'Z95', 'Z98'), 'NA', lusdot)
    lusdot <- ifelse(lusdot=='NA' & ! V41_USDOT_SCR_GRPS %in% c('Z92', 'Z95', 'Z98'), '0-2', lusdot)
    paste0(BMT_NO_LIV, '_', V41_USDOT_SCR_GRPS, '_', lusdot)
  }]
  base_data[, BMT_V41_USDOT_LUSDOT:=as.factor(BMT_V41_USDOT_LUSDOT)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
