library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PUC_CRDT_BCG'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'POWER_UNIT_CNT', 'CR_TIER')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[, PUC_CRDT_BCG:={
    puc <- ifelse(POWER_UNIT_CNT>10, 10, ifelse(POWER_UNIT_CNT<1, 1, POWER_UNIT_CNT))
    bcg <- ifelse(BMT_NO_LIV=='C-Tow', 'B', 'A')
    crdt <- as.character(CR_TIER)
    crdt <- ifelse(crdt=='NC', 'XX', crdt)
    paste0(puc, '_', crdt, '_', bcg)
  }]
  
  # FACTOR FORMATTING
  base_data[, PUC_CRDT_BCG:=as.factor(PUC_CRDT_BCG)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
