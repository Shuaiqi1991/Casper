library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'CR_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('CR_TIER')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ IN LOOKUP TABLE
  lookup_grp <- fread(here(var_lib_path, 'CR_GRP', 'lookup_grp.csv'))
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('CR_GRP' %in% names(base_data)) base_data[, CR_GRP:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- lookup_grp[base_data, on=.(CR_TIER)]
  base_data[is.na(CR_GRP), CR_GRP:='Z']
  base_data[, CR_GRP:=as.factor(CR_GRP)]
  base_data[, CR_TIER:=as.factor(CR_TIER)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
