library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BCG_BT'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('SIC_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLES
  lookup_bc <- fread(here(var_lib_path, 'BCG_BT', 'lookup_bc.csv'))
  
  # FORMATTING
  lookup_bc[, SIC_CD:=str_pad(SIC_CD, width=4, side='left', pad='0')]
  
  # DELETE EXISTING VARIABLE, IF IT EXISTS
  if ('BCG_BT' %in% names(base_data)) base_data[, BCG_BT:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- lookup_bc[base_data, on=.(SIC_CD)]
  
  # NAs
  base_data[is.na(BCG_BT), BCG_BT:='Retailers']
  
  # ENSURE FACTOR FORMATTING
  base_data[, BCG_BT:=as.factor(BCG_BT)]
  base_data[, SIC_CD:=as.factor(SIC_CD)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))  
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
