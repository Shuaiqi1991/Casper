library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'VEH_BODY_TYP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN POLICIES
  bt_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_BODY_TYP
    FROM 
      CAW.VEHICLE, 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.VEHICLE.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.VEHICLE.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.VEHICLE.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.VEHICLE.PHYS_VEH_KEY, 
      CAW.VEHICLE.VEH_BODY_TYP
    ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  bt_qry <- str_replace_all(bt_qry, 'startdate', start_date)
  bt_qry <- str_replace_all(bt_qry, 'enddate', end_date)
  
  # RUN QUERIES
  bt_data <- as.data.table(dbGetQuery(caw_con, bt_qry))
  
  # FORMATTING
  bt_data[, VEH_BODY_TYP:=trimws(VEH_BODY_TYP)]
  bt_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('VEH_BODY_TYP' %in% names(base_data)) base_data[, VEH_BODY_TYP:=NULL]

  # JOIN BT ONTO BASE DATASET
  base_data <- bt_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}
