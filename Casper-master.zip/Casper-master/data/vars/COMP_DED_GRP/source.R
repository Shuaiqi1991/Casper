library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'COMP_DED_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('COMP_DED_AMT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_ded <- fread(here(var_lib_path, 'COMP_DED_GRP', 'lookup_ded.csv'))
  lookup_ded[, COMP_DED_AMT:=as.factor(COMP_DED_AMT)]
  lookup_ded[, COMP_DED_GRP:=as.factor(COMP_DED_GRP)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('COMP_DED_GRP' %in% names(base_data)) base_data[, COMP_DED_GRP:=NULL]
  
  # JOIN DED ONTO BASE DATASET
  base_data <- lookup_ded[base_data, on=.(COMP_DED_AMT)]
  
  # FORMATTING
  base_data[is.na(COMP_DED_GRP), COMP_DED_GRP:='999']
 
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
