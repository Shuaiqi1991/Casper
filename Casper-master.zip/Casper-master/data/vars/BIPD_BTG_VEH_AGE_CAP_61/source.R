library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BIPD_BTG_VEH_AGE_CAP_61'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_AGE_CAP_61', 'BIPD_BTG_VEH_AGE_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE BTG AND VEH AGE
  base_data[, BIPD_BTG_VEH_AGE_CAP_61:=paste0(BIPD_BTG_VEH_AGE_GRP, '_', VEH_AGE_CAP_61)]
  
  # FACTORIZE
  base_data[, BIPD_BTG_VEH_AGE_CAP_61:=as.factor(BIPD_BTG_VEH_AGE_CAP_61)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
