library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'ST_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # GET LOOKUP TABLE
  lookup_st <- fread(here(var_lib_path, 'ST_GRP', 'lookup_st.csv'))
  lookup_st[, ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  
  # DELETE EXISTING COLUMN, IF APPLICABLE
  if ('ST_GRP' %in% names(base_data)) base_data[, ST_GRP:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  base_data <- lookup_st[base_data, on=.(ST_CD)]
  
  # MISSING VALUES
  largest_st_grp <- base_data[, .N, by=.(ST_GRP)][which.max(N), ST_GRP]
  n_missing <- base_data[is.na(ST_GRP), .N]
  plog("ST_GRP: Mapping ", n_missing, " missing values to ST_GRP ", largest_st_grp)
  base_data[is.na(ST_GRP), ST_GRP:=largest_st_grp]
  
  # FORMATTING
  base_data[, ST_GRP:=as.factor(ST_GRP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}
