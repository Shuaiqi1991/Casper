library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PUC_GRP_TIER'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('POWER_UNIT_CNT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # GROUPING
  base_data[, PUC_GRP_TIER:=ifelse(POWER_UNIT_CNT %in% c(0,1), '1',
                                   ifelse(POWER_UNIT_CNT<5, '2-4', '5+'))]
  base_data[is.na(POWER_UNIT_CNT), PUC_GRP_TIER:='1']
  
  # FORMATTING
  base_data[, PUC_GRP_TIER:=as.factor(PUC_GRP_TIER)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
