library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PRNCPL_MATCH_IND'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CLOB FOR FR DATA
  clob_con <- dbConnect(odbc(), 'CLOB', uid=uid, pwd=pwd)
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CLOB QUERY
  clob_qry <- "
    SELECT
      P.ST_CD AS ALPHA_ST_CD,
      P.POL_NBR,
      P.SUFFIX AS RENW_SFX_NBR,
      F.FIN_STBL_INSD_FRST_NM,
      F.FIN_STBL_INSD_LST_NM,
      F.FIN_STBL_INSD_DOB
    FROM 
      POLICY AS P,
      FIN_STBL AS F
    WHERE 
      P.POLICY_ID = F.POLICY_ID
      AND P.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    GROUP BY
      P.ST_CD,
      P.POL_NBR,
      P.SUFFIX,
      F.FIN_STBL_INSD_FRST_NM,
      F.FIN_STBL_INSD_LST_NM,
      F.FIN_STBL_INSD_DOB
  "
  # INSERT DATES INTO QUERY
  clob_qry <- str_replace_all(clob_qry, 'startdate', start_date)
  clob_qry <- str_replace_all(clob_qry, 'enddate', end_date)
  
  # RUN QUERY
  clob_data <- as.data.table(dbGetQuery(clob_con, clob_qry))
  
  # FILTER BLANKS
  clob_data <- clob_data[FIN_STBL_INSD_FRST_NM!='']
  
  # EXTRACT POL_ID_NBR FROM POL_NBR
  clob_data[, POL_NBR:=substr(POL_NBR, 1, 8)]
  setnames(clob_data, 'POL_NBR', 'POL_ID_NBR')
  clob_data[, POL_ID_NBR:=as.integer(POL_ID_NBR)]
  
  # GET STATE CODES
  dse_qry <- "SELECT DSE.STATE.ALPHA_ST_CD, DSE.STATE.ST_CD FROM DSE.STATE"
  dse_data <- as.data.table(dbGetQuery(caw_con, dse_qry))
  clob_data <- dse_data[clob_data, on=.(ALPHA_ST_CD)]
  clob_data[, ALPHA_ST_CD:=NULL]

  # CAW QUERY
  caw_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.RENW_SFX_NBR, 
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POLICY.CR_INVLV_IND,
      CAW.DRVR_PUB_VIEW.FRST_NAM, 
      CAW.DRVR_PUB_VIEW.LST_NAM, 
      CAW.DRVR_PUB_VIEW.DRVR_BRTH_DT,
      CAW.POLICY.CR_SCORE_CD, 
      CAW.DRVR_PUB_VIEW.EXCL_IND, 
      CAW.DRVR_PUB_VIEW.EXCL_DRVR_IND 
    FROM 
      CAW.BUSTYP, 
      CAW.DRVR_PUB_VIEW, 
      CAW.POLICY, 
      CAW.POL_DATES 
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POLICY.PHYS_POL_KEY = CAW.DRVR_PUB_VIEW.PHYS_POL_KEY 
      AND CAW.POLICY.ST_CD = CAW.DRVR_PUB_VIEW.ST_CD 
      AND CAW.POLICY.SIC_CD = CAW.BUSTYP.CV_INDSTR_CLSS_CD 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.POL_ID_NBR, 
      CAW.POLICY.RENW_SFX_NBR, 
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POLICY.CR_INVLV_IND,
      CAW.DRVR_PUB_VIEW.FRST_NAM, 
      CAW.DRVR_PUB_VIEW.LST_NAM, 
      CAW.DRVR_PUB_VIEW.DRVR_BRTH_DT,
      CAW.POLICY.CR_SCORE_CD, 
      CAW.DRVR_PUB_VIEW.EXCL_IND, 
      CAW.DRVR_PUB_VIEW.EXCL_DRVR_IND 
  ;
  "
  # INSERT DATES INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))

  # FORMATTING 
  caw_data[, FRST_NAM:=trimws(FRST_NAM)]
  caw_data[, LST_NAM:=trimws(LST_NAM)]
  
  # MERGE CAW AND CLOB DATA
  caw_data <- merge(caw_data, clob_data, c('ST_CD', 'POL_ID_NBR', 'RENW_SFX_NBR'))
  
  # FLAG DIRTY DATA AND EXCEPTIONS
  caw_data[, PRNCPL_MATCH_IND:=0]
  caw_data[is.na(FIN_STBL_INSD_DOB), PRNCPL_MATCH_IND:=1]
  caw_data[str_to_upper(FIN_STBL_INSD_FRST_NM)=='DISPATCH', PRNCPL_MATCH_IND:=1]
  caw_data[str_to_upper(FIN_STBL_INSD_LST_NM)=='DISPATCH', PRNCPL_MATCH_IND:=1]
  caw_data[str_to_upper(FIN_STBL_INSD_LST_NM)=='CREDITDEMO', PRNCPL_MATCH_IND:=1]
  caw_data[grepl('[0-9]', FIN_STBL_INSD_FRST_NM), PRNCPL_MATCH_IND:=1]
  caw_data[FIN_STBL_INSD_DOB<=as.Date('1900-01-01'), PRNCPL_MATCH_IND:=1]
  caw_data[CR_SCORE_CD %in% c('NA','I1','P1','O1','Q1','NC'), PRNCPL_MATCH_IND:=1]
  caw_data[is.na(CR_SCORE_CD), PRNCPL_MATCH_IND:=1]
  
  # EXCLUDED DRIVER INDICATOR
  caw_data[, DRVR_EXCL:='N']
  caw_data[EXCL_IND=='Y'|EXCL_DRVR_IND=='Y', DRVR_EXCL:='Y']
  
  # CHECK APPROXIMATE BIRTH DATE MATCH
  # 0 - 1: NO MATCH
  # 2: APPROXIMATE MATCH
  # 3: EXACT MATCH
  caw_data[, BRTH_DT_MATCH:=(lubridate::day(DRVR_BRTH_DT) == lubridate::day(FIN_STBL_INSD_DOB)) +
                               (lubridate::month(DRVR_BRTH_DT) == lubridate::month(FIN_STBL_INSD_DOB)) +
                               (lubridate::year(DRVR_BRTH_DT) == lubridate::year(FIN_STBL_INSD_DOB))]
  
  # FLAG PRINCIPAL FR LISTED (FOR NON-EXCLUDED DRIVERS)
  caw_data[LST_NAM==FIN_STBL_INSD_LST_NM & BRTH_DT_MATCH>=2 & DRVR_EXCL=='N', PRNCPL_MATCH_IND:=1]
  caw_data[substr(FRST_NAM, 1, 1)==substr(FIN_STBL_INSD_FRST_NM, 1, 1) & 
             BRTH_DT_MATCH==3 & DRVR_EXCL=='N', PRNCPL_MATCH_IND:=1]
  
  # FLAG POLICIES WHERE FR IS NOT INVOLVED IN BUSINESS OPERATIONS
  caw_data[CR_INVLV_IND!='Y', PRNCPL_MATCH_IND:=0]
  
  # SUMMARIZE BY POLICY
  caw_data <- caw_data[, .(PRNCPL_MATCH_IND=sum(PRNCPL_MATCH_IND)), by=.(ST_CD, PHYS_POL_KEY)]
  caw_data[, PRNCPL_MATCH_IND:=ifelse(PRNCPL_MATCH_IND==0, 'N', 'Y')]
  
  # DELETE EXISTING COLUMN
  if ('PRNCPL_MATCH_IND' %in% names(base_data)) base_data[, PRNCPL_MATCH_IND:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # NAs BECOME PRNCPL_MATCH_IND 'N'
  base_data[is.na(PRNCPL_MATCH_IND), PRNCPL_MATCH_IND:='N']
  
  # FORMATTING
  base_data[, PRNCPL_MATCH_IND:=as.factor(PRNCPL_MATCH_IND)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
