library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'NUM_DRVRS_INCP_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # DRIVER DATES QUERY
  dts_qry <- 
  "
    SELECT DISTINCT
      CAW.DRVR_DATES.ST_CD, 
      CAW.DRVR_DATES.PHYS_POL_KEY, 
      CAW.DRVR_DATES.DRVR_POS_CNT
    FROM 
      CAW.DRVR_DATES
    WHERE
      CAW.DRVR_DATES.POL_STRT_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.DRVR_DATES.DRVR_STRT_DT = CAW.DRVR_DATES.POL_STRT_DT
      AND CAW.DRVR_DATES.DRVR_STOP_DT <> CAW.DRVR_DATES.POL_STRT_DT
    ;
  "
  
  # INSERT START AND END DATE INTO QUERY
  dts_qry <- str_replace_all(dts_qry, 'startdate', start_date)
  dts_qry <- str_replace_all(dts_qry, 'enddate', end_date)
  
  # GET DRIVER DATES DATA
  dts_data <- as.data.table(dbGetQuery(caw_con, dts_qry))
  
  # GET COUNTS
  dts_data <- dts_data[, .(NUM_DRVRS_INCP=.N), by=.(ST_CD, PHYS_POL_KEY)]
  
  # GROUPING
  dts_data[, NUM_DRVRS_INCP_GRP:=ifelse(NUM_DRVRS_INCP==1, '1',
                                        ifelse(NUM_DRVRS_INCP<5, '2-4', '5+'))]
  
  # DELETE EXISTING VARIABLE
  if ('NUM_DRVRS_INCP_GRP' %in% names(base_data)) base_data[, NUM_DRVRS_INCP_GRP:=NULL]
  
  # JOIN VARIABLE ONTO BASE DATASET
  dts_data <- dts_data[, .(ST_CD, PHYS_POL_KEY, NUM_DRVRS_INCP_GRP)]
  base_data <- dts_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMATTING
  base_data[is.na(NUM_DRVRS_INCP_GRP), NUM_DRVRS_INCP_GRP:='2-4']
  base_data[, NUM_DRVRS_INCP_GRP:=as.factor(NUM_DRVRS_INCP_GRP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
