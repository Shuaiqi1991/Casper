library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'PREF_TRUCK'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('V41_USDOT_SCR_GRPS',
                                           'SIC_CD',
                                           'CR_TIER',
                                           'UW_ROW',
                                           'BMT_NO_LIV')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY,
      CAW.POL_DATES.POL_EFF_DT,
      CAW.POLICY.BSNS_STRT_YR, 
	    CAW.POLICY.COH_INCP_DT, 
    	MIN(CAW.DRVR_PUB_VIEW.DRVR_AGE) AS MIN_DRVR_AGE, 
      CEIL(SUM(CAW.DRVR_PUB_VIEW.DRVR_PTS) / COUNT(DISTINCT CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY)) as AVG_DRVR_PTS
    FROM 
    	CAW.DRVR_DATES, 
    	CAW.DRVR_PUB_VIEW, 
    	CAW.POLICY, 
    	CAW.POL_DATES 
    WHERE 
    	CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
    	AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
    	AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
    	AND CAW.POLICY.PHYS_POL_KEY = CAW.DRVR_PUB_VIEW.PHYS_POL_KEY 
    	AND CAW.POLICY.ST_CD = CAW.DRVR_PUB_VIEW.ST_CD 
    	AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
    	AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
    	AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
    	AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
    	AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
    	AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.DRVR_DATES.DRVR_STRT_DT = CAW.POL_DATES.POL_EFF_DT
      AND CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND = 'N'
    GROUP BY
      CAW.POLICY.ST_CD, 
    	CAW.POLICY.PHYS_POL_KEY,
      CAW.POL_DATES.POL_EFF_DT,
      CAW.POLICY.BSNS_STRT_YR, 
	    CAW.POLICY.COH_INCP_DT
  ;
  "
  # INSERT DATES INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # CALCULATE YEARS IN BUSINESS
  caw_data[, YIB:=lubridate::year(POL_EFF_DT) - lubridate::year(COH_INCP_DT)]
  caw_data[BSNS_STRT_YR > 0 & BSNS_STRT_YR <= lubridate::year(COH_INCP_DT), 
           YIB:=lubridate::year(POL_EFF_DT) - BSNS_STRT_YR]
  caw_data[, POL_EFF_DT:=NULL]
  caw_data[, COH_INCP_DT:=NULL]
  caw_data[, BSNS_STRT_YR:=NULL]
  
  # JOIN TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # DELETE EXISTING COLUMN
  if ('PREF_TRUCK' %in% names(base_data)) base_data[, PREF_TRUCK:=NULL]
  
  # CREATE PREFERRED TRUCK INDICATOR
  good_credit <- c('A0','A1','A2','A3','B0','B1','B2','B3','C0','C1','C2','C3')
  bad_credit <- c('D0','D1','D2','E0','E1','E2','T1','T3','T4','T5','X1','X3','X4','XX','I1','NA','O1')
  base_data[, PREF_TRUCK:='N']
  base_data[V41_USDOT_SCR_GRPS %in% c('A01', 'A02', 'A03') &
              !(SIC_CD %in% c('7546','4211')) &
              MIN_DRVR_AGE >= 23 &
              CALC_LUSDOT_YRS >= 3 &
              UW_ROW == '4' &
              CR_TIER %in% good_credit &
              AVG_DRVR_PTS <= 1,
            PREF_TRUCK:='Y']
  base_data[V41_USDOT_SCR_GRPS=='Z98' &
              !(SIC_CD %in% c('7546','4211')) &
              MIN_DRVR_AGE >= 23 &
              YIB >= 3 &
              UW_ROW == '4' &
              CR_TIER %in% good_credit &
              AVG_DRVR_PTS <= 1,
            PREF_TRUCK:='N']
  base_data[BMT_NO_LIV %in% c('D-Contractors', 'E-Business Auto'), PREF_TRUCK:='BACON']
  
  # DROP UNNECESSARY COLUMNS
  base_data[, MIN_DRVR_AGE:=NULL]
  base_data[, AVG_DRVR_PTS:=NULL]
  base_data[, YIB:=NULL]
  
  # FORMATTING
  base_data[, PREF_TRUCK:=as.factor(PREF_TRUCK)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
