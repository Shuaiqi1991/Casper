library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BCG_RAD'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('SIC_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_sic <- fread(here(var_lib_path, 'BCG_RAD', 'lookup_sic.csv'))
  lookup_sic[, SIC_CD:=str_pad(SIC_CD, width=4, side='left', pad='0')]
  
  # DELETE EXISTING FIELDS, IF APPLICABLE
  if ('BCG_RAD' %in% names(base_data)) base_data[, BCG_RAD:=NULL]
  
  # LOOKUP BCG RAD ON BASE DATA
  base_data <- lookup_sic[base_data, on=.(SIC_CD)]
  base_data[, SIC_CD:=as.factor(SIC_CD)]
  
  # FORMATTING
  base_data[is.na(BCG_RAD), BCG_RAD:=2]
  base_data[, BCG_RAD:=as.factor(BCG_RAD)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
