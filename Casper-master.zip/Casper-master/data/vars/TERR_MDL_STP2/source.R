library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'TERR_MDL_STP2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('TERR_MDL')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # DUPLICATE COLUMN
  base_data[, TERR_MDL_STP2:=TERR_MDL]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
