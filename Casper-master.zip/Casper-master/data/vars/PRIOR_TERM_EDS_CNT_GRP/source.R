library(data.table)

# DEFINE VARIABLE
var_name <- 'PRIOR_TERM_EDS_CNT_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('PRIOR_TERM_EDS_CNT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # BUILD VARIABLE
  base_data[, PRIOR_TERM_EDS_CNT_GRP:=as.character(PRIOR_TERM_EDS_CNT)]
  base_data[is.na(PRIOR_TERM_EDS_CNT), PRIOR_TERM_EDS_CNT_GRP:='U']
  base_data[RENW_SFX_NBR==0, PRIOR_TERM_EDS_CNT_GRP:='U']
  base_data[PRIOR_TERM_EDS_CNT >= 5, PRIOR_TERM_EDS_CNT_GRP:='5+']
  base_data[PRIOR_TERM_EDS_CNT <= 0, PRIOR_TERM_EDS_CNT_GRP:='0']
  
  # FORMATTING
  base_data[, PRIOR_TERM_EDS_CNT_GRP:=as.factor(PRIOR_TERM_EDS_CNT_GRP)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
