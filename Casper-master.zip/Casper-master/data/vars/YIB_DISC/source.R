library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'YIB_DISC'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- "
    SELECT
      CAW.POLICY.ST_CD
      ,CAW.POLICY.PHYS_POL_KEY
      ,CAW.POLICY.COH_INCP_DT
      ,CAW.POLICY.BSNS_STRT_YR
    FROM
      CAW.POLICY
      ,CAW.POL_DATES
    WHERE
      CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR
  "
  
  # REPLACE DATES IN QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERY
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # CREATE VARIABLE
  caw_data[, YIB_DISC:='N']
  caw_data[(lubridate::year(COH_INCP_DT)-BSNS_STRT_YR)>=3, YIB_DISC:='Y']
  caw_data[(BSNS_STRT_YR==0) | (BSNS_STRT_YR<1900), YIB_DISC:='U']
  caw_data[(BSNS_STRT_YR==9999), YIB_DISC:='N']
  
  # REMOVE UNNECESARY COLUMNS
  caw_data[, BSNS_STRT_YR:=NULL]
  caw_data[, COH_INCP_DT:=NULL]
  
  # DELETE COLUMN IF IT ALREADY EXISTS
  if ('YIB_DISC' %in% names(base_data)) base_data[, YIB_DISC:=NULL]
  
  # JOIN DATA TO BASE DATA
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # MAP NAs TO N
  base_data[is.na(YIB_DISC), YIB_DISC:='N']
  
  # FACTOR FORMATTING
  base_data[, YIB_DISC:=as.factor(YIB_DISC)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
