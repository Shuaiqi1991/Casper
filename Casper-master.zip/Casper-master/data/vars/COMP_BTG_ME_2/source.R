library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'COMP_BTG_ME_2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_BODY_TYP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ IN LOOKUP TABLE
  lookup_bt <- fread(here(var_lib_path, 'COMP_BTG_ME_2', 'lookup_btg_me.csv'))

  # FORMATTING
  lookup_bt[, VEH_BODY_TYP:=str_pad(VEH_BODY_TYP, width=2, side='left', pad='0')]
  lookup_bt[, COMP_BTG_ME_2:=as.character(COMP_BTG_ME_2)]
    
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('COMP_BTG_ME_2' %in% names(base_data)) base_data[, COMP_BTG_ME_2:=NULL]

  # JOIN COLL_BTG_ME ONTO BASE DATASET
  base_data <- lookup_bt[base_data, on=.(VEH_BODY_TYP)]
  
  # FORMATTING
  base_data[, COMP_BTG_ME_2:=as.factor(COMP_BTG_ME_2)]
  base_data[, VEH_BODY_TYP:=as.factor(VEH_BODY_TYP)]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
