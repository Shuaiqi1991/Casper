library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'CDL_PCT_STP2'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('CDL_PCT')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # DUPLICATE CDL PCT VARIABLES
  base_data[, CDL_PCT_NAMES_STP2:=paste0(CDL_PCT_NAMES, '_STP2')]
  base_data[, CDL_PCT_NAMES_STP2:=as.factor(CDL_PCT_NAMES_STP2)]
  base_data[, CDL_N_PCT_STP2:=CDL_N_PCT]
  base_data[, CDL_U_PCT_STP2:=CDL_U_PCT]
  base_data[, CDL_Y_PCT_STP2:=CDL_Y_PCT]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
