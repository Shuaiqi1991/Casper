library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'PIF_DISC'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # QUERY TO OBTAIN POLICIES
  caw_qry <- "
    SELECT 
    	CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.BILL_PLN_CD
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_EFF_DT  BETWEEN {d 'startdate'} and {d 'enddate'}
      AND CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR
    GROUP BY
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY, 
      CAW.POLICY.BILL_PLN_CD
      ;
  "
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERIES
  caw_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # FORMATTING
  caw_data[, BILL_PLN_CD:=trimws(BILL_PLN_CD)]
  
  # CREATE PIF DISCOUNT
  caw_data[, PIF_DISC:=ifelse(BILL_PLN_CD %in% c('C1','CB'), 'Y', 'N')]
  caw_data[, BILL_PLN_CD:=NULL]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('PIF_DISC' %in% names(base_data)) base_data[, PIF_DISC:=NULL]

  # JOIN ONTO BASE DATASET
  base_data <- caw_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMATTING
  base_data[! PIF_DISC %in% c('N','Y'), PIF_DISC:='N']
  base_data[, PIF_DISC:=as.factor(PIF_DISC)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  return(base_data)
}