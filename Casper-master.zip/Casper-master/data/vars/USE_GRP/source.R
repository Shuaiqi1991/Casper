library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'USE_GRP'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('VEH_USE_CD')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # READ LOOKUP TABLE
  lookup_use <- fread(here(var_lib_path, 'USE_GRP', 'lookup_use.csv'))
  lookup_use[, VEH_USE_CD:=as.factor(VEH_USE_CD)]
  lookup_use[, USE_GRP:=as.factor(USE_GRP)]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('USE_GRP' %in% names(base_data)) base_data[, USE_GRP:=NULL]
  
  # JOIN USE ONTO BASE DATASET
  base_data <- lookup_use[base_data, on=.(VEH_USE_CD)]
  
  # FORMATTING
  base_data[is.na(USE_GRP), USE_GRP:='999']
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
