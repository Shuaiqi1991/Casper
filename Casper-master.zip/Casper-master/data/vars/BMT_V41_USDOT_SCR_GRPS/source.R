library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'BMT_V41_USDOT_SCR_GRPS'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BMT_NO_LIV', 'V41_USDOT_SCR_GRPS')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
   
  # GROUP USDOT_SCR_GRPS
  base_data[V41_USDOT_SCR_GRPS %in% c('A01','A02','A03'), USDOT_SCR_GRP_TEMP:='Low']
  base_data[V41_USDOT_SCR_GRPS %in% c('A04','A05','A06'), USDOT_SCR_GRP_TEMP:='Med']
  base_data[V41_USDOT_SCR_GRPS %in% c('A07','A08','A09','A10'), USDOT_SCR_GRP_TEMP:='High']
  base_data[V41_USDOT_SCR_GRPS %in% c('A07','A08','A09','A10'), USDOT_SCR_GRP_TEMP:='High']
  base_data[V41_USDOT_SCR_GRPS %in% c('Z92','Z95'), USDOT_SCR_GRP_TEMP:='NVs']
  base_data[V41_USDOT_SCR_GRPS %in% c('Z98'), USDOT_SCR_GRP_TEMP:='Z98']
  
  # BUILD VARIABLE
  base_data[, BMT_V41_USDOT_SCR_GRPS:=paste0(BMT_NO_LIV, '_', USDOT_SCR_GRP_TEMP)]
  base_data[, BMT_V41_USDOT_SCR_GRPS:=as.factor(BMT_V41_USDOT_SCR_GRPS)]
  
  # DROP UNECESSARY COLUMNS
  base_data[, USDOT_SCR_GRP_TEMP:=NULL]

  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
