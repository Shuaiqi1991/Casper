library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'OOS_DRVR_POL_LVL_V0'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # CAW QUERY
  caw_qry <- 
  "
    SELECT
      CAW.POLICY.ST_CD
      ,CAW.POLICY.PHYS_POL_KEY
      ,CAW.POLICY.SIC_CD
      ,CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY
      ,CAW.DRVR_DATES.DRVR_AT_INCP_IND
      ,CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
      ,CAW.DRVR_PUB_VIEW.EXCL_IND
      ,CAW.DRVR_PUB_VIEW.DRVR_LIC_ST_CD
    FROM
      CAW.POL_DATES, 
      CAW.DRVR_DATES, 
      CAW.DRVR_PUB_VIEW, 
      CAW.POLICY
    WHERE 
      CAW.POL_DATES.POL_STOP_DT >= {d 'startdate'}
      AND CAW.POL_DATES.POL_EFF_DT <= {d 'enddate'}
      AND CAW.POLICY.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
      AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
      AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
      AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
      AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
      AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
      AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
      AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
      AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
      AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR
    GROUP BY
      CAW.POLICY.ST_CD
      ,CAW.POLICY.PHYS_POL_KEY
      ,CAW.POLICY.SIC_CD
      ,CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY
      ,CAW.DRVR_DATES.DRVR_AT_INCP_IND
      ,CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
      ,CAW.DRVR_PUB_VIEW.EXCL_IND
      ,CAW.DRVR_PUB_VIEW.DRVR_LIC_ST_CD
  ;"
  
  # INSERT SELECTED START AND END DATE INTO QUERY
  caw_qry <- str_replace_all(caw_qry, 'startdate', start_date)
  caw_qry <- str_replace_all(caw_qry, 'enddate', end_date)
  
  # RUN QUERIES
  drv_data <- as.data.table(dbGetQuery(caw_con, caw_qry))
  
  # LOOKUP ST_CD
  lookup_st <- fread(here(var_lib_path, 'OOS_DRVR_POL_LVL_V0', 'lookup_st.csv'))
  lookup_st[, DRVR_LIC_ST_CD_NUM:=str_pad(DRVR_LIC_ST_CD_NUM, width=2, side='left', pad='0')]
  drv_data <- lookup_st[drv_data, on=.(DRVR_LIC_ST_CD)]
  
  # DEFAULT: OOS DRIVER = Y
  drv_data[, OOS_DRVR:=1]
  drv_data[DRVR_LIC_ST_CD_NUM==ST_CD, OOS_DRVR:=0]
  drv_data[is.na(DRVR_LIC_ST_CD_NUM), OOS_DRVR:=0]
  
  # AGGREGATE DRIVER LEVEL TO POLICY LEVEL:
  # IF AT LEAST ONE DRIVER IS OUT OF STATE, THEN OOS_DRVR_POL_LVL = Y
  drv_data <- drv_data[, .(OOS_DRVR_POL_LVL_V0=max(OOS_DRVR)), by=.(ST_CD, PHYS_POL_KEY)]
  drv_data[, OOS_DRVR_POL_LVL_V0:=ifelse(OOS_DRVR_POL_LVL_V0==1, 'Y', 'N')]
  
  # DELETE EXISTING FIELD, IF APPLICABLE
  if ('OOS_DRVR_POL_LVL_V0' %in% names(base_data)) base_data[, OOS_DRVR_POL_LVL_V0:=NULL]
  
  # JOIN ONTO BASE DATASET
  base_data <- drv_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # FORMATTING
  base_data[! OOS_DRVR_POL_LVL_V0 %in% c('N', 'Y'), OOS_DRVR_POL_LVL_V0:='N']
  base_data[, OOS_DRVR_POL_LVL_V0:=as.factor(OOS_DRVR_POL_LVL_V0)]
  
  # RETURN BASE DATA
  return(base_data)
}
