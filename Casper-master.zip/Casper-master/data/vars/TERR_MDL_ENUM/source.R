library(data.table)
library(odbc)

# DEFINE VARIABLE
var_name <- 'TERR_MDL_ENUM'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('TERR_MDL')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # FACTORIZE TERR_MDL
  base_data[, TERR_MDL_ENUM:=as.factor(TERR_MDL)]
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
