library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'PSRC_VIO_CNTS'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c()

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  start_date <- args[['start_date']]
  end_date <- args[['end_date']]
  uid <- args[['uid']]
  pwd <- args[['pwd']]
  base_data <- args[['base_data']]
  
  # CONNECT TO CAW
  caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)
  
  # VIOLATIONS QUERY
  viol_qry <- 
  "
    SELECT 
    	CAW.DRIVER_VIOL.ST_CD, 
      CAW.DRIVER_VIOL.PHYS_POL_KEY, 
      CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
      CAW.DRIVER_VIOL.VIOL_CD, 
      CAW.DRIVER_VIOL.DRVR_INCID_DT, 
      CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
    FROM 
      CAW.DRIVER_VIOL
    WHERE 
      CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
    ;
  "
  
  # DRIVER DATES QUERY
  dts_qry <- 
  "
    SELECT 
    	CAW.DRVR_DATES.ST_CD, 
    	CAW.DRVR_DATES.PHYS_POL_KEY, 
      CAW.DRVR_DATES.PHYS_DRVR_KEY,
    	CAW.DRVR_DATES.DRVR_POS_CNT, 
    	CAW.DRVR_DATES.DRVR_STRT_DT,
      CAW.DRVR_DATES.DRVR_STOP_DT
    FROM 
    	CAW.DRVR_DATES
    WHERE
      CAW.DRVR_DATES.POL_STRT_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    ;
  "
  
  # POLICY DATES QUERY
  pol_qry <- 
  "
    SELECT 
      CAW.POLICY.ST_CD, 
      CAW.POLICY.PHYS_POL_KEY,
      CAW.POLICY.POL_TERM,
      CAW.POL_DATES.POL_EFF_DT,
      CAW.POL_DATES.POL_STRT_DT,
      CAW.POL_DATES.POL_STOP_DT
    FROM 
      CAW.POL_DATES, 
      CAW.POLICY 
    WHERE 
      CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
      AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
      AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
      AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
    ;
  "
  
  # INSERT START AND END DATE INTO QUERY
  min_pol_expr_yr <- lubridate::year(as.Date(start_date))
  pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(today())+1)
  pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
  pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
  viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
  dts_qry <- str_replace_all(dts_qry, 'startdate', start_date)
  dts_qry <- str_replace_all(dts_qry, 'enddate', end_date)
  pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
  pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)
  
  # GET VIOLATION DATA
  viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))
  
  # GET DRIVER DATES DATA
  dts_data <- as.data.table(dbGetQuery(caw_con, dts_qry))
  
  # GET POLICY DATES
  pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))
  
  # GET FIRST DRIVER DATE
  dts_data <- dts_data[order(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT, DRVR_STRT_DT)]
  first_inds <- dts_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
  dts_data <- dts_data[first_inds]
  
  # JOIN VIOLATION AND DATES DATA
  viol_data <- dts_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # JOIN DATES AND VIOLATION DATA
  viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))
  
  # NA DRIVER START DATES ARE ASSIGNED TO POLICY EFFECTIVE DATE
  viol_data[is.na(DRVR_STRT_DT), DRVR_STRT_DT:=POL_EFF_DT]
  
  # DELETE VIOLATION DATE > START DATE
  viol_data <- viol_data[!(DRVR_INCID_DT > DRVR_STRT_DT)]
  
  # DELETE DRVR_PNT_SRC_CD P & L
  viol_data[, DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]
  viol_data <- viol_data[DRVR_PNT_SRCE_CD=='P']
  
  # DELETE NON-INCEPTION DRIVERS
  viol_data <- viol_data[POL_STRT_DT==DRVR_STRT_DT]
  
  # DELETE SAME DAY START-STOP DRIVERS
  viol_data <- viol_data[!(DRVR_STRT_DT==DRVR_STOP_DT)]
  
  # LOOKUP VIOLATION CLASS
  lookup_vio_cls <- fread(here(var_lib_path, 'PSRC_VIO_CNTS', 'lookup_vio_cls.csv'))
  viol_data[, VIOL_CD:=trimws(VIOL_CD)]
  viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
  # IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
  viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']
  
  # ASSIGN POINTS FOR FIRST VIOLATION
  viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
  first_viol_pts <- fread(here(var_lib_path, 'PSRC_VIO_CNTS', 'lookup_first_pts.csv'))
  viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

  # ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
  addtl_viol_pts <- fread(here(var_lib_path, 'PSRC_VIO_CNTS', 'lookup_addtl_pts.csv'))
  setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
  viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
  first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
  viol_data[!first_inds, VIOL_PT:=ADDTL_PT]
  
  # REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
  viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
  first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
  viol_data <- viol_data[first_inds]
  
  # REASSIGN POINTS AFTER SAME DAY FILTER
  # viol_data[, VIOL_PT:=NULL]
  # viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
  # viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]
  # viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
  # first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
  # viol_data[!first_inds, VIOL_PT:=ADDTL_PT]
  
  # SUMMARIZE POINT SUM TO DRIVER LEVEL
  # viol_data <- viol_data[, .(DRVR_PTS=sum(VIOL_PT)), by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
  
  # CALCULATE LOOKBACK PERIOD
  viol_data[, LKBK_PERIOD:=as.numeric(POL_STRT_DT - DRVR_INCID_DT)/365]
  viol_data[, POL_TERM:=as.integer(POL_TERM)]
  viol_data[, CURR_TERM_VIOL:={
    prior_start <- POL_STRT_DT %m+% months(-POL_TERM)
    (DRVR_INCID_DT >= prior_start) & (DRVR_INCID_DT < POL_STRT_DT) 
  }]
  viol_data[, PRIOR_TERM_VIOL:={
    prior_start <- POL_STRT_DT %m+% months(-POL_TERM)
    prior_3yr_start <- prior_start %m+% years(-3)
    (DRVR_INCID_DT >= prior_3yr_start) & (DRVR_INCID_DT < prior_start) 
  }]
  
  # CALCULATE MAJ_5YR_CNT
  # cds <- c('CRD','DR','FAR','FEL','FLE','FRA','HOM','LTS','RKD','SUS','WOC')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, MAJ_5YR_CNT:=1]
  # viol_data[VIOL_CD %in% cds & CURR_TERM_VIOL, MAJ_CURR_TERM_CNT:=1]
  # viol_data[VIOL_CD %in% cds & PRIOR_TERM_VIOL, MAJ_PRIOR_TERM_CNT:=1]
  
  # CALCULATE DUI_5YR_CNT
  # cds <- c('BOT','DWI','REF')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, DUI_5YR_CNT:=1]
  # viol_data[VIOL_CD %in% cds & CURR_TERM_VIOL, DUI_CURR_TERM_CNT:=1]
  # viol_data[VIOL_CD %in% cds & PRIOR_TERM_VIOL, DUI_PRIOR_TERM_CNT:=1]
  
  # CALCULATE MIN_5YR_CNT
  # cds <- c('DEQ','DEV','FTC','FTY','IBK','IP','IT','LIC','MMV','SAF','SCH','SPD','WSR','OVW','SBV','SP1','SP2')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, MIN_5YR_CNT:=1]
  # viol_data[VIOL_CD %in% cds & CURR_TERM_VIOL, MIN_CURR_TERM_CNT:=1]
  # viol_data[VIOL_CD %in% cds & PRIOR_TERM_VIOL, MIN_PRIOR_TERM_CNT:=1]
  
  # CALCULATE AAF_5YR_CNT
  cds <- c('AAF', 'AC1', 'CAF', 'CC1')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, AAF_5YR_CNT:=1]
  viol_data[VIOL_CD %in% cds & CURR_TERM_VIOL, AAF_CURR_TERM_PSRC_CNT:=1]
  viol_data[VIOL_CD %in% cds & PRIOR_TERM_VIOL, AAF_PRIOR_TERM_PSRC_CNT:=1]
  
  # CALCULATE NAF_5YR_CNT
  cds <- c('NAF', 'AFN', 'AFR', 'ANC', 'ANO', 'CFN', 'CNF')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, NAF_5YR_CNT:=1]
  viol_data[VIOL_CD %in% cds & CURR_TERM_VIOL, NAF_CURR_TERM_PSRC_CNT:=1]
  viol_data[VIOL_CD %in% cds & PRIOR_TERM_VIOL, NAF_PRIOR_TERM_PSRC_CNT:=1]
  
  # CALCULATE LPAW_5YR_LKBK
  # cds <- c('ANC')
  # viol_data[VIOL_CD %in% cds & LKBK_PERIOD > 0 & LKBK_PERIOD <= 5, LPAW_5YR_LKBK:=1]
  
  # CALCULATE FDL_LKBK
  # viol_data[VIOL_CD=='FDL', FDL_LKBK:=1]
  
  # CALCULATE UDR_LKBK
  # viol_data[VIOL_CD=='UDR', UDR_LKBK:=1]
  
  # SUM VIOLATIONS TO POLICY LEVEL
  vio_cols <- c('AAF_CURR_TERM_PSRC_CNT', 'AAF_PRIOR_TERM_PSRC_CNT',
                'NAF_CURR_TERM_PSRC_CNT', 'NAF_PRIOR_TERM_PSRC_CNT')
  viol_data <- viol_data[, lapply(.SD, sum, na.rm=T),
                         by=.(ST_CD, PHYS_POL_KEY),
                         .SDcols=c(vio_cols)]
  
  # DELETE EXISTING COLUMNS FROM BASE, IF ANY
  for (col in vio_cols) {
    if (col %in% names(base_data)) base_data[, c(col):=NULL]
  }
  
  # JOIN TO BASE DATA
  base_data <- viol_data[base_data, on=.(ST_CD, PHYS_POL_KEY)]
  
  # MAP NAs TO 0
  for (col in vio_cols) {
    base_data[, c(col):=ifelse(is.na(get(col)), 0, get(col))]
  }
  
  # RENAME COLUMNS
  new_cols <- c('RBT_PRG_AAF_CNT', 'PRG_AAF_VIO_CNT',
                'RBT_PRG_NAF_CNT', 'PRG_NAF_VIO_CNT')
  
  # DELETE EXISTING COLUMNS FROM BASE, IF ANY
  for (col in new_cols) {
    if (col %in% names(base_data)) base_data[, c(col):=NULL]
  }
  
  setnames(base_data, vio_cols, new_cols)
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
