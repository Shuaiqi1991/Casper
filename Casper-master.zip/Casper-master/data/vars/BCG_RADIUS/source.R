library(data.table)
library(odbc)
library(stringr)

# DEFINE VARIABLE
var_name <- 'BCG_RADIUS'

var_lib[[var_name]] <- list()

var_lib[[var_name]][['dependencies']] <- c('BCG_RAD', 'RADIUS_GRP')

var_lib[[var_name]][['builder']] <- function(...) {
  
  # GET ARGUMENTS
  args <- list(...)
  base_data <- args[['base_data']]
  
  # CONCATENATE FIELDS
  base_data[, BCG_RADIUS:=paste0(BCG_RAD, '_', RADIUS_GRP)]
  
  # FORMATTING
  base_data[, BCG_RADIUS:=as.factor(BCG_RADIUS)]
  
  # CHECK DATA LENGTH
  print(length(base_data$ST_CD))
  
  # RETURN BASE DATA
  return(base_data)
}

# LOAD DEPENDENCIES
for (var in var_lib[[var_name]][['dependencies']]) {
  if (! var %in% names(var_lib)) {
    plog('Loading dependency ', var, ' definition...')
    source(here(var_lib_path, var, 'source.R'), local=TRUE)
  }
}
