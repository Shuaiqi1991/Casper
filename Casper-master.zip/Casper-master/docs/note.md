#### **Hardware recommendataion**
In order to run this app smoothly, the recommended RAM is 128GB or no smaller than 64 GB.

When creating CAPP 2019 data, the 64 GB RAM workstation still occasionally encounter out of memory issue and sometimes cause program crash.

Considering the increasing book of business every year, Please use workstations with largest RAM if possible to aviod situations mentioned above. 

#### ** suggestion for creating data**
TERR_MDL : after building it, check mixing of each terr_mdl value and make sure ecy mix for terr_mdl=0 is not too big (there's case where lot of mis-joining just go to terr_mdl = 0 )